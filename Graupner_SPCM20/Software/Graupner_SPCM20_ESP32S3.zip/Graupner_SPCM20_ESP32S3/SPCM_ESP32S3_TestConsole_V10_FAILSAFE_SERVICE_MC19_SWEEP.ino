/*
  ============================================================================
  Graupner / JR SPCM 1024 Generator - ESP32-S3
  Test console - V10 CH1..CH10 + FAIL-SAFE / SERVICE MC-19
  ============================================================================

  Output:
      GPIO 1

  Console:
      C1 1000
      C1 1500
      C1 2000
      ...
      C8 1750
      C9 1000

      SHOW
      N
      HELP

  Current status:
      - 8 absolute channels
      - 900..2100 us -> 0..1023 SPCM
      - CRC A/B/C/D implemented
      - physical Table 1 implemented
      - V5 parity-dependent end of frame
      - CH9: AUX1/AUX3, fallback AUX5/AUX7
      - CH10: AUX2/AUX4, fallback AUX6/AUX8

  IMPORTANT:
      This is still a test generator, not the final RculSpcmGen library.
*/
/*
Connexion SPCM sur carte HF MC19
              +10 V
                │
              4,7 kΩ
                │
                +────────── SPCM vers module HF
                │
                C
GPIO1 ── 4,7k ─ B   BC547
                E
                │
GND ESP32 ──────┴────────── GND module HF

*/
#include <Arduino.h>
#include "esp_timer.h"
#include "driver/gpio.h"

#define SPCM_PIN 1

static constexpr uint32_t FRAME_US = 44025;
static constexpr uint32_t SYNC_US  = 415;

// -----------------------------------------------------------------------------
// Inverte signal GPIO1 (only if NPN is used)
// -----------------------------------------------------------------------------

static inline void spcmWrite(bool level)
{
    // BC547 en collecteur ouvert :
    // GPIO LOW  -> BC547 OFF -> sortie +10 V
    // GPIO HIGH -> BC547 ON  -> sortie ~0 V
    gpio_set_level((gpio_num_t)SPCM_PIN, level ? 0 : 1);
}

// -----------------------------------------------------------------------------
// Channel values exposed to the application
// -----------------------------------------------------------------------------

static uint16_t ChannelUs[8] =
{
    1500, 1500, 1500, 1500,
    1500, 1500, 1500, 1500
};

static uint32_t FrameNumber = 0;

// -----------------------------------------------------------------------------
// SWEEP test C1..C8
// -----------------------------------------------------------------------------
static bool SweepEnabled = false;
static uint32_t SweepStartMs = 0;

static void updateSweep()
{
    if (!SweepEnabled)
        return;

    // Same diagnostic principle as the Uno version:
    // triangle 1000 -> 2000 -> 1000 us, about 4 s per full cycle,
    // with 250 ms phase shift between channels.
    const uint32_t now = millis() - SweepStartMs;

    for (uint8_t ch = 0; ch < 8; ch++)
    {
        uint32_t t = (now + (uint32_t)ch * 250UL) % 4000UL;
        uint16_t us;

        if (t < 2000UL)
            us = (uint16_t)(1000UL + t / 2UL);
        else
            us = (uint16_t)(2000UL - (t - 2000UL) / 2UL);

        ChannelUs[ch] = us;
    }
}


// -----------------------------------------------------------------------------
// V7 high channels
//
// CH9  : 8-bit, upper nibble AUX1/q0,  lower nibble AUX3/q3
// CH10 : 8-bit, upper nibble AUX2/q18, lower nibble AUX4/q21
//
// The existing V5 Service table is preserved. A high-channel value replaces
// only a genuine high-channel slot (both corresponding AUX values < 16).
// Relative/failsafe/service values 16/20/24/28 are therefore untouched.
// -----------------------------------------------------------------------------

static uint16_t Channel9Us = 1500;
static uint16_t Channel10Us = 1500;

// Fail-Safe CH1..CH8.
// 0 means FS disabled / HOLD, exactly as defined by SPCM.
// Non-zero values store the quantized 10-bit FS value (bits 1..0 forced to 0).
static uint16_t FailsafeSpcm[8] = {0,0,0,0,0,0,0,0};




// -----------------------------------------------------------------------------
// Quintet -> physical octet
// -----------------------------------------------------------------------------

static const uint8_t QuintetToPhysical[32] =
{
    0x01, 0x44, 0x50, 0x48,
    0x14, 0x24, 0x54, 0x28,
    0x0A, 0x42, 0x09, 0x41,
    0x12, 0x22, 0x11, 0x21,
    0x02, 0x04, 0x40, 0x20,
    0x51, 0x08, 0x52, 0x10,
    0x45, 0x25, 0x05, 0x15,
    0x49, 0x29, 0x4A, 0x2A
};


// -----------------------------------------------------------------------------
// AUX pattern observed on the real transmitter at neutral.
//
// Order of each row:
// q0, q3, q8, q11, q18, q21, q26, q29
// -----------------------------------------------------------------------------

// V10: Service/AUX cycle measured from the new MC-19 Fail-Safe capture.
// Only this table differs from V9 in the protocol generator.
static const uint8_t Service[8][8] =
{
    // AUX1 AUX3 AUX5 AUX7  AUX2 AUX4 AUX6 AUX8
    {28,28,24,24,  8, 0,28,20},
    { 8, 0,28,28, 28,16,16,24},
    {16,16,16,16,  8, 0,20,28},
    { 8, 0,20,20, 16,20,24,16},
    {20,20,24,24,  8, 0,28,20},
    { 8, 0,28,28, 20,24,16,24},
    {24,24,16,16,  8, 0,20,28},
    { 8, 0,20,20, 24,28,24,16}
};


// =============================================================================
// CRC-8 SPCM
// =============================================================================

static uint8_t spcmCrc8(const uint8_t data[4], uint8_t poly)
{
    uint8_t crc = 0;

    for (uint8_t n = 0; n < 4; n++)
    {
        crc ^= data[n];

        for (uint8_t bit = 0; bit < 8; bit++)
        {
            if (crc & 0x80)
                crc = (uint8_t)((crc << 1) ^ poly);
            else
                crc <<= 1;
        }
    }

    return crc;
}


// =============================================================================
// Public-style channel setter
// =============================================================================

static void setChannelUs(uint8_t channel, uint16_t us)
{
    if (channel < 1 || channel > 8)
        return;

    if (us < 900)
        us = 900;

    if (us > 2100)
        us = 2100;

    ChannelUs[channel - 1] = us;
}


// =============================================================================
// us -> SPCM 10-bit
// =============================================================================

static uint16_t usToSpcm(uint16_t us)
{
    if (us <= 900)
        return 0;

    if (us >= 2100)
        return 1023;

    return ((uint32_t)(us - 900) * 1023UL + 600UL) / 1200UL;
}


// =============================================================================
// us -> SPCM CH9 8-bit
//
// CH9/CH10 use the upper 8 bits of the normal 10-bit SPCM scale.
// 900 us -> 0, 1500 us -> 128, 2100 us -> 255.
// =============================================================================

static uint8_t usToSpcmHighChannel(uint16_t us)
{
    uint16_t v10 = usToSpcm(us);
    return (uint8_t)(v10 >> 2);
}


// =============================================================================
// Put a 10-bit channel value in two quintets
// =============================================================================

static void setSpcmChannel(uint8_t q[32], uint8_t position, uint16_t value)
{
    value &= 0x03FF;

    q[position]     = (value >> 5) & 0x1F;
    q[position + 1] = value & 0x1F;
}


// =============================================================================
// Build the 32 protected bits:
// six quintets (30 bits) + ctrlHigh (2 bits)
// =============================================================================

static void makeProtectedData(
    const uint8_t q[32],
    uint8_t start,
    uint8_t ctrlHigh,
    uint8_t data[4])
{
    uint8_t bits[32];
    uint8_t p = 0;

    for (uint8_t n = 0; n < 6; n++)
    {
        uint8_t v = q[start + n] & 0x1F;

        for (int8_t b = 4; b >= 0; b--)
            bits[p++] = (v >> b) & 1;
    }

    bits[p++] = (ctrlHigh >> 1) & 1;
    bits[p++] = ctrlHigh & 1;

    for (uint8_t n = 0; n < 4; n++)
    {
        uint8_t v = 0;

        for (uint8_t b = 0; b < 8; b++)
            v = (uint8_t)((v << 1) | bits[n * 8 + b]);

        data[n] = v;
    }
}


// =============================================================================
// Build one 10-bit CTRL field
// =============================================================================

static void makeCtrl(
    uint8_t q[32],
    uint8_t start,
    uint8_t ctrlPosition,
    uint8_t ctrlHigh,
    uint8_t polynomial)
{
    uint8_t data[4];

    makeProtectedData(q, start, ctrlHigh, data);

    uint8_t crc = spcmCrc8(data, polynomial);

    uint16_t ctrl =
        ((uint16_t)(ctrlHigh & 0x03) << 8) |
        crc;

    q[ctrlPosition]     = (ctrl >> 5) & 0x1F;
    q[ctrlPosition + 1] = ctrl & 0x1F;
}


// =============================================================================
// V6 CH9
//
// CH9 is an 8-bit extra channel. Its upper nibble is carried by AUX1 (q0)
// and its lower nibble by AUX3 (q3). The validated V5 Service table already
// contains CH9=0x80 on the Extra-Channel slots (q0=8, q3=0).
// V6 replaces only those slots; all FS/service slots remain untouched.
// =============================================================================


// =============================================================================
// Fail-Safe helpers
//
// FS is a 10-bit channel value, but only FS9..FS2 are transmitted.
// FS1..FS0 are always zero. FS=0 has the special meaning "FS disabled/HOLD".
//
// An FS AUX quintet is:
//   bit4    = 1
//   bits3:2 = index 0..3
//   bits1:0 = FS3:2, FS5:4, FS7:6, FS9:8 according to the index.
//
// The normal Service table already supplies bit4 and the index (16/20/24/28).
// We only replace bits1:0.
// =============================================================================

static uint16_t failsafeUsToSpcm(uint16_t us)
{
    uint16_t v = usToSpcm(us);
    return v & 0x03FC; // force FS1..FS0 = 0
}

static uint8_t makeFailsafeAux(uint8_t serviceBase, uint16_t fs)
{
    uint8_t index = (serviceBase >> 2) & 0x03;
    uint8_t part  = (fs >> (2 + 2 * index)) & 0x03;
    return (serviceBase & 0x1C) | part;
}

static void applyFailsafeToAux(uint8_t &aux, uint8_t channelIndex)
{
    // Values 16..31 are FS/service fields. Values <16 are Extra/Relative data
    // and must not be modified here.
    if (aux >= 16)
        aux = makeFailsafeAux(aux, FailsafeSpcm[channelIndex]);
}

static void setFailsafeUs(uint8_t ch, uint16_t us)
{
    if (ch < 1 || ch > 8)
        return;
    FailsafeSpcm[ch - 1] = failsafeUsToSpcm(us);
}

static void setFailsafeOff(uint8_t ch)
{
    if (ch < 1 || ch > 8)
        return;
    FailsafeSpcm[ch - 1] = 0;
}


// =============================================================================
// Build the 32 logical quintets
// =============================================================================

static void buildLogicalFrame(uint8_t q[32], uint32_t frameNumber)
{
    memset(q, 0, 32);

    uint8_t s = frameNumber & 7;

    // AUX fields
    q[0]  = Service[s][0];
    q[3]  = Service[s][1];
    q[8]  = Service[s][2];
    q[11] = Service[s][3];
    q[18] = Service[s][4];
    q[21] = Service[s][5];
    q[26] = Service[s][6];
    q[29] = Service[s][7];

    // -------------------------------------------------------------------------
    // Fail-Safe CH1..CH8
    //
    // Aux mapping:
    // AUX1=q0 -> CH1, AUX2=q18 -> CH2, AUX3=q3 -> CH3, AUX4=q21 -> CH4
    // AUX5=q8 -> CH5, AUX6=q26 -> CH6, AUX7=q11 -> CH7, AUX8=q29 -> CH8
    //
    // Service values 16/20/24/28 already carry the FS index. We insert the
    // corresponding two FS bits. Extra-channel slots (<16) are left untouched.
    // -------------------------------------------------------------------------
    applyFailsafeToAux(q[0],  0); // CH1 / AUX1
    applyFailsafeToAux(q[18], 1); // CH2 / AUX2
    applyFailsafeToAux(q[3],  2); // CH3 / AUX3
    applyFailsafeToAux(q[21], 3); // CH4 / AUX4
    applyFailsafeToAux(q[8],  4); // CH5 / AUX5
    applyFailsafeToAux(q[26], 5); // CH6 / AUX6
    applyFailsafeToAux(q[11], 6); // CH7 / AUX7
    applyFailsafeToAux(q[29], 7); // CH8 / AUX8

    // -------------------------------------------------------------------------
    // Extra channels CH9 / CH10
    //
    // The Service table explicitly schedules their primary slots:
    //   CH9  -> AUX1/AUX3 when q0/q3 < 16
    //   CH10 -> AUX2/AUX4 when q18/q21 < 16
    //
    // Backup AUX5/AUX7 and AUX6/AUX8 are required when a PRIMARY field is
    // temporarily taken over by Relative Channel Data. V9 does not yet generate
    // relative channel updates, so no backup substitution is needed here.
    // This avoids overwriting valid FS data in the backup AUX fields.
    // -------------------------------------------------------------------------
    const uint8_t ch9 = usToSpcmHighChannel(Channel9Us);
    if (q[0] < 16 && q[3] < 16)
    {
        q[0] = (ch9 >> 4) & 0x0F;
        q[3] = ch9 & 0x0F;
    }

    const uint8_t ch10 = usToSpcmHighChannel(Channel10Us);
    if (q[18] < 16 && q[21] < 16)
    {
        q[18] = (ch10 >> 4) & 0x0F;
        q[21] = ch10 & 0x0F;
    }

    // Absolute channels
    setSpcmChannel(q, 16, usToSpcm(ChannelUs[0])); // CH1
    setSpcmChannel(q,  1, usToSpcm(ChannelUs[1])); // CH2
    setSpcmChannel(q, 19, usToSpcm(ChannelUs[2])); // CH3
    setSpcmChannel(q,  4, usToSpcm(ChannelUs[3])); // CH4
    setSpcmChannel(q, 24, usToSpcm(ChannelUs[4])); // CH5
    setSpcmChannel(q,  9, usToSpcm(ChannelUs[5])); // CH6
    setSpcmChannel(q, 27, usToSpcm(ChannelUs[6])); // CH7
    setSpcmChannel(q, 12, usToSpcm(ChannelUs[7])); // CH8

    // Simple mode: both AUX control bits = 1.
    //
    // CRC polynomials:
    // A = 0x31
    // B = 0x13
    // C = 0x91
    // D = 0x19

    makeCtrl(q,  0,  6, 3, 0x31);
    makeCtrl(q,  8, 14, 3, 0x13);
    makeCtrl(q, 16, 22, 3, 0x91);
    makeCtrl(q, 24, 30, 3, 0x19);
}


// =============================================================================
// Convert 32 quintets to 256 physical bits
// =============================================================================

static void makePhysicalBits(const uint8_t q[32], uint8_t bits[256])
{
    uint16_t p = 0;

    for (uint8_t n = 0; n < 32; n++)
    {
        uint8_t physical =
            QuintetToPhysical[q[n] & 0x1F];

        for (int8_t b = 7; b >= 0; b--)
            bits[p++] = (physical >> b) & 1;
    }
}


// =============================================================================
// Timing helpers
// =============================================================================

static inline void waitUntilUs(uint64_t target)
{
    while ((int64_t)(esp_timer_get_time() - target) < 0)
    {
    }
}


static inline uint32_t ticksToUs(uint16_t ticks)
{
    // 1 tick = 166.4 us
    return ((uint32_t)ticks * 1664UL + 5UL) / 10UL;
}


// =============================================================================
// Physical SPCM generator V5
// =============================================================================

static void sendPhysicalFrame(const uint8_t bits[256])
{
    static uint64_t nextFrameUs = 0;

    if (nextFrameUs == 0)
        nextFrameUs = esp_timer_get_time();

    waitUntilUs(nextFrameUs);

    uint64_t frameStart = nextFrameUs;

    nextFrameUs += FRAME_US;

    // -------------------------------------------------------------------------
    // SYNC HIGH
    // -------------------------------------------------------------------------

    spcmWrite(1);

    uint64_t syncEnd =
        frameStart + SYNC_US;

    waitUntilUs(syncEnd);

    spcmWrite(0);


    // -------------------------------------------------------------------------
    // Locate first 1 and count parity
    // -------------------------------------------------------------------------

    int firstOne = -1;
    uint16_t ones = 0;

    for (int i = 0; i < 256; i++)
    {
        if (bits[i])
        {
            ones++;

            if (firstOne < 0)
                firstOne = i;
        }
    }

    if (firstOne < 0)
        return;


    // -------------------------------------------------------------------------
    // First transition after sync
    // -------------------------------------------------------------------------

    waitUntilUs(
        syncEnd +
        ticksToUs(firstOne + 1));

    bool level = true;

    spcmWrite(1);


    // -------------------------------------------------------------------------
    // Remaining physical 1 bits
    // -------------------------------------------------------------------------

    for (int i = firstOne + 1; i < 256; i++)
    {
        if (!bits[i])
            continue;

        waitUntilUs(
            syncEnd +
            ticksToUs(i + 1));

        level = !level;

        spcmWrite(level);
    }


    // -------------------------------------------------------------------------
    // Graupner end-of-frame pattern
    //
    // Even number of 1:
    //      tick 258 -> HIGH
    //      tick 260 -> LOW
    //
    // Odd number of 1:
    //      tick 260 -> LOW
    // -------------------------------------------------------------------------

    if ((ones & 1) == 0)
    {
        waitUntilUs(
            syncEnd +
            ticksToUs(258));

        spcmWrite(1);

        waitUntilUs(
            syncEnd +
            ticksToUs(260));

        spcmWrite(0);
    }
    else
    {
        waitUntilUs(
            syncEnd +
            ticksToUs(260));

        spcmWrite(0);
    }
}


// =============================================================================
// Console
// =============================================================================

static void showChannels()
{
    Serial.println();
    Serial.println(F("SPCM channels:"));

    for (uint8_t ch = 0; ch < 8; ch++)
    {
        Serial.printf(
            "  CH%u = %4u us   SPCM=%4u\n",
            ch + 1,
            ChannelUs[ch],
            usToSpcm(ChannelUs[ch]));
    }

    Serial.printf(
        "  CH9 = %4u us   SPCM8=%3u\n",
        Channel9Us, usToSpcmHighChannel(Channel9Us));
    Serial.printf(
        "  CH10= %4u us   SPCM8=%3u\n",
        Channel10Us, usToSpcmHighChannel(Channel10Us));

    Serial.printf("SWEEP = %s\n", SweepEnabled ? "ON" : "OFF");

    Serial.println(F("Fail-Safe CH1..CH8:"));
    for (uint8_t ch = 0; ch < 8; ch++)
    {
        if (FailsafeSpcm[ch] == 0)
            Serial.printf("  FS%u = HOLD/OFF\n", ch + 1);
        else
            Serial.printf("  FS%u = SPCM %u\n", ch + 1, FailsafeSpcm[ch]);
    }

    Serial.println();
}


static void showHelp()
{
    Serial.println();
    Serial.println(F("Graupner/JR SPCM test console"));
    Serial.println(F("--------------------------------"));
    Serial.println(F("C1 1000   Set CH1 to 1000 us"));
    Serial.println(F("C8 1750   Set CH8 to 1750 us"));
    Serial.println(F("C9 1000   Set CH9  (8-bit extra channel)"));
    Serial.println(F("C10 1000  Set CH10 (8-bit extra channel)"));
    Serial.println(F("            900..2100 us -> 0..255"));
    Serial.println(F("Valid range: 900..2100 us"));
    Serial.println(F("FS1 1000  Set CH1 Fail-Safe position"));
    Serial.println(F("FS8 1750  Set CH8 Fail-Safe position"));
    Serial.println(F("FH1       CH1 Fail-Safe HOLD/OFF"));
    Serial.println(F("FHA       HOLD/OFF for all CH1..CH8"));
    Serial.println(F("SHOW      Show all channels"));
    Serial.println(F("SWEEP ON  Sweep CH1..CH8 1000..2000 us"));
    Serial.println(F("SWEEP OFF Stop sweep and keep current positions"));
    Serial.println(F("N         Set all channels to 1500 us"));
    Serial.println(F("HELP      Show this help"));
    Serial.println();
}


static void processConsoleLine(char *line)
{
    while (*line == ' ' || *line == '\t')
        line++;

    if (*line == 0)
        return;

    if (!strcasecmp(line, "SHOW"))
    {
        showChannels();
        return;
    }

    if (!strcasecmp(line, "SWEEP ON"))
    {
        SweepEnabled = true;
        SweepStartMs = millis();
        Serial.println(F("SWEEP ON - CH1..CH8 1000..2000 us"));
        return;
    }

    if (!strcasecmp(line, "SWEEP OFF"))
    {
        SweepEnabled = false;
        Serial.println(F("SWEEP OFF - current CH1..CH8 positions retained"));
        return;
    }

    if (!strcasecmp(line, "HELP") ||
        !strcmp(line, "?"))
    {
        showHelp();
        return;
    }

    if (!strcasecmp(line, "N") ||
        !strcasecmp(line, "NEUTRAL"))
    {
        for (uint8_t ch = 1; ch <= 8; ch++)
            setChannelUs(ch, 1500);

        Channel9Us = 1500;
        Channel10Us = 1500;

        Serial.println(F("All channels CH1..CH10 -> 1500 us"));
        showChannels();
        return;
    }


    // Fail-Safe commands:
    // FS1 1000  -> store CH1 FS position
    // FH1       -> disable FS / HOLD on CH1
    // FHA       -> disable FS / HOLD on CH1..CH8

    if (!strcasecmp(line, "FHA"))
    {
        for (uint8_t ch = 1; ch <= 8; ch++)
            setFailsafeOff(ch);
        Serial.println(F("Fail-Safe CH1..CH8 -> HOLD/OFF"));
        return;
    }

    if ((line[0] == 'F' || line[0] == 'f') &&
        (line[1] == 'H' || line[1] == 'h'))
    {
        long ch = strtol(line + 2, nullptr, 10);
        if (ch < 1 || ch > 8)
        {
            Serial.println(F("Syntax: FH1 ... FH8"));
            return;
        }
        setFailsafeOff((uint8_t)ch);
        Serial.printf("FS CH%ld -> HOLD/OFF\n", ch);
        return;
    }

    if ((line[0] == 'F' || line[0] == 'f') &&
        (line[1] == 'S' || line[1] == 's'))
    {
        char *p = line + 2;
        char *end;
        long ch = strtol(p, &end, 10);
        while (*end == ' ' || *end == '\t') end++;

        if (ch < 1 || ch > 8 || *end == 0)
        {
            Serial.println(F("Syntax: FS1 1500 ... FS8 1500"));
            return;
        }

        long us = strtol(end, nullptr, 10);
        if (us < 900 || us > 2100)
        {
            Serial.println(F("FS range: 900..2100 us"));
            return;
        }

        setFailsafeUs((uint8_t)ch, (uint16_t)us);
        Serial.printf("FS CH%ld = %ld us -> SPCM %u (quantized, bits1..0=0)\n",
                      ch, us, FailsafeSpcm[ch - 1]);
        return;
    }

    // Accept:
    // C1 1500
    // c1 1500

    if (line[0] == 'C' || line[0] == 'c')
    {
        char *p = line + 1;
        char *end;

        long ch = strtol(p, &end, 10);

        while (*end == ' ' || *end == '\t')
            end++;

        if (ch < 1 || ch > 10 || *end == 0)
        {
            Serial.println(F("Syntax: C1 1500 ... C10 1500"));
            return;
        }

        long us = strtol(end, nullptr, 10);

        if (us < 900 || us > 2100)
        {
            Serial.println(F("Range: 900..2100 us"));
            return;
        }

        if (ch == 9)
        {
            Channel9Us = (uint16_t)us;
            uint8_t ch9 = usToSpcmHighChannel(Channel9Us);
            Serial.printf(
                "CH9 = %ld us  -> SPCM8 %u (0x%02X)\n",
                us, ch9, ch9);
            return;
        }

        if (ch == 10)
        {
            Channel10Us = (uint16_t)us;
            uint8_t ch10 = usToSpcmHighChannel(Channel10Us);
            Serial.printf(
                "CH10 = %ld us  -> SPCM8 %u (0x%02X)\n",
                us, ch10, ch10);
            return;
        }

        setChannelUs((uint8_t)ch, (uint16_t)us);

        Serial.printf(
            "CH%ld = %ld us  -> SPCM %u\n",
            ch,
            us,
            usToSpcm((uint16_t)us));

        return;
    }

    Serial.println(F("Unknown command. Type HELP."));
}


static void consoleTask()
{
    static char line[64];
    static uint8_t pos = 0;

    while (Serial.available())
    {
        char c = (char)Serial.read();

        if (c == '\r' || c == '\n')
        {
            if (pos)
            {
                line[pos] = 0;
                processConsoleLine(line);
                pos = 0;
            }
        }
        else
        {
            if (pos < sizeof(line) - 1)
                line[pos++] = c;
        }
    }
}


// =============================================================================
// Arduino setup
// =============================================================================

void setup()
{
    Serial.begin(115200);

    pinMode(SPCM_PIN, OUTPUT);
    digitalWrite(SPCM_PIN, LOW);

    delay(500);

    Serial.println();
    Serial.println(F("=============================================="));
    Serial.println(F(" Graupner/JR SPCM 1024 - ESP32-S3 test V10 CH1..CH10 + FAIL-SAFE / SERVICE MC-19"));
    Serial.println(F(" GPIO 1"));
    Serial.println(F("=============================================="));

    for (uint8_t ch = 1; ch <= 8; ch++)
        setChannelUs(ch, 1500);

    Channel9Us = 1500;
    Channel10Us = 1500;

    showHelp();
    showChannels();
}


// =============================================================================
// Arduino loop
// =============================================================================

void loop()
{
    uint8_t q[32];
    uint8_t bits[256];

    // Console is checked once per frame.
    consoleTask();
    updateSweep();

    buildLogicalFrame(q, FrameNumber);
    makePhysicalBits(q, bits);
    sendPhysicalFrame(bits);

    FrameNumber++;
}
