/*
  Graupner / JR SPCM 1024 Generator - Arduino Mega 2560 / ATmega2560
  V11 PT5 FULL-PT - builder durees incremental
  Timer1 /8 + OC1B hardware toggle, architecture proche OpenAVRc

  Objectif de cette version:
    - reprendre la construction logique/tableaux de la version ESP32 V10 validee
    - C1..C10
    - SWEEP ON/OFF
    - console de test: C1..C10, SHOW, N/NEUTRAL, SWEEP ON/OFF, HELP
    - Fail-Safe C1..C8 repris de la V10 ESP32 validee
    - #define SPCM_FAILSAFE_ENABLED permet de le bloquer pour OpenAVRc
    - Timer1 /8 comme OpenAVRc, sortie D12 / PB6 / OC1B hardware toggle

  Sortie electrique (BC547 comme lors des essais):

                 +6V (ou tension pull-up validee)
                   |
                 4.7k
                   |
                   +------ SPCM vers module HF
                   |
                   C
  D12 -- 4.7k ----B  BC547
                   E
                   |
                  GND

  IMPORTANT:
    Le BC547 inverse le signal. spcmSetLogical() tient compte de cette inversion.
*/

#include <Arduino.h>
#include <avr/interrupt.h>
#include <util/atomic.h>
#include "src/pt/pt.h"

#if !defined(__AVR_ATmega2560__)
  #error "Cette V11 est configuree pour Arduino Mega 2560 / ATmega2560 (SPCM sur D12/PB6/OC1B)."
#endif

#define SPCM_PIN 12               // ATmega2560: PB6 = OC1B = Arduino D12
#define SPCM_BIT _BV(PB6)

// Fail-Safe SPCM.
// 1 = Fail-Safe actif et commandes FS1..FS8 / FH1..FH8 / FHA disponibles.
// 0 = Fail-Safe totalement bloque : les champs FS sont emis en HOLD/OFF.
// Pour l'integration OpenAVRc actuelle, mettre a 0 tant qu'OpenAVRc ne le gere pas.
#define SPCM_FAILSAFE_ENABLED 1

// -----------------------------------------------------------------------------
// Channels
// -----------------------------------------------------------------------------
static volatile uint16_t ChannelUs[8] = {
  1500,1500,1500,1500,1500,1500,1500,1500
};
static volatile uint16_t Channel9Us  = 1500;
static volatile uint16_t Channel10Us = 1500;
static volatile uint32_t FrameNumber = 0;
static volatile uint32_t BufferSwapCount = 0;

// Fail-Safe C1..C8, format SPCM 10 bits quantifie.
// 0 = HOLD/OFF. Les bits 1..0 sont toujours forces a 0.
static volatile uint16_t FailsafeSpcm[8] = {0,0,0,0,0,0,0,0};

// -----------------------------------------------------------------------------
// SWEEP C1..C8
// -----------------------------------------------------------------------------
static bool SweepEnabled = false;
static uint32_t SweepStartMs = 0;

static void updateSweep()
{
  if (!SweepEnabled) return;

  const uint32_t now = millis() - SweepStartMs;
  uint16_t newUs[8];

  // Calculs avec interruptions actives : ne pas bloquer UART ni Timer1 SPCM.
  for (uint8_t ch=0; ch<8; ch++) {
    uint32_t t = (now + (uint32_t)ch * 250UL) % 4000UL;

    if (t < 2000UL)
      newUs[ch] = (uint16_t)(1000UL + t/2UL);
    else
      newUs[ch] = (uint16_t)(2000UL - (t-2000UL)/2UL);
  }

  // Section atomique minimale : copie seulement les 8 valeurs.
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    for (uint8_t ch=0; ch<8; ch++)
      ChannelUs[ch] = newUs[ch];
  }
}

// -----------------------------------------------------------------------------
// Quintet -> physical octet : identique ESP32 valide
// -----------------------------------------------------------------------------
static const uint8_t QuintetToPhysical[32] PROGMEM = {
  0x01,0x44,0x50,0x48, 0x14,0x24,0x54,0x28,
  0x0A,0x42,0x09,0x41, 0x12,0x22,0x11,0x21,
  0x02,0x04,0x40,0x20, 0x51,0x08,0x52,0x10,
  0x45,0x25,0x05,0x15, 0x49,0x29,0x4A,0x2A
};

// Cycle Service MC-19 de la version ESP32 validee.
static const uint8_t Service[8][8] PROGMEM = {
  // AUX1 AUX3 AUX5 AUX7   AUX2 AUX4 AUX6 AUX8
  {28,28,24,24,   8, 0,28,20},
  { 8, 0,28,28,  28,16,16,24},
  {16,16,16,16,   8, 0,20,28},
  { 8, 0,20,20,  16,20,24,16},
  {20,20,24,24,   8, 0,28,20},
  { 8, 0,28,28,  20,24,16,24},
  {24,24,16,16,   8, 0,20,28},
  { 8, 0,20,20,  24,28,24,16}
};

static uint8_t spcmCrc8(const uint8_t data[4], uint8_t poly)
{
  uint8_t crc=0;
  for (uint8_t n=0;n<4;n++) {
    crc ^= data[n];
    for (uint8_t b=0;b<8;b++)
      crc = (crc & 0x80) ? (uint8_t)((crc<<1)^poly) : (uint8_t)(crc<<1);
  }
  return crc;
}

static uint16_t usToSpcm(uint16_t us)
{
  if (us <= 900) return 0;
  if (us >= 2100) return 1023;
  return ((uint32_t)(us-900)*1023UL + 600UL)/1200UL;
}

static uint8_t usToSpcmHighChannel(uint16_t us)
{
  return (uint8_t)(usToSpcm(us)>>2);
}

static void setSpcmChannel(uint8_t q[32], uint8_t pos, uint16_t value)
{
  value &= 0x03FF;
  q[pos]   = (value>>5)&0x1F;
  q[pos+1] = value&0x1F;
}

static void makeProtectedData(const uint8_t q[32], uint8_t start,
                              uint8_t ctrlHigh, uint8_t data[4])
{
  uint8_t bits[32];
  uint8_t p=0;
  for (uint8_t n=0;n<6;n++) {
    uint8_t v=q[start+n]&0x1F;
    for (int8_t b=4;b>=0;b--) bits[p++]=(v>>b)&1;
  }
  bits[p++]=(ctrlHigh>>1)&1;
  bits[p++]=ctrlHigh&1;
  for (uint8_t n=0;n<4;n++) {
    uint8_t v=0;
    for (uint8_t b=0;b<8;b++) v=(uint8_t)((v<<1)|bits[n*8+b]);
    data[n]=v;
  }
}

static void makeCtrl(uint8_t q[32], uint8_t start, uint8_t ctrlPos,
                     uint8_t ctrlHigh, uint8_t poly)
{
  uint8_t data[4];
  makeProtectedData(q,start,ctrlHigh,data);
  uint16_t ctrl=((uint16_t)(ctrlHigh&3)<<8)|spcmCrc8(data,poly);
  q[ctrlPos]=(ctrl>>5)&0x1F;
  q[ctrlPos+1]=ctrl&0x1F;
}

// -----------------------------------------------------------------------------
// Fail-Safe SPCM, repris de la version ESP32 V10 validee.
// Un champ FS utilise bit4=1, bits3:2=index 0..3, bits1:0=fragment FS.
// -----------------------------------------------------------------------------
static uint16_t failsafeUsToSpcm(uint16_t us)
{
  return usToSpcm(us) & 0x03FC; // FS1..FS0 forces a 0
}

static uint8_t makeFailsafeAux(uint8_t serviceBase, uint16_t fs)
{
  const uint8_t index = (serviceBase >> 2) & 0x03;
  const uint8_t part  = (fs >> (2 + 2 * index)) & 0x03;
  return (serviceBase & 0x1C) | part;
}

static inline uint8_t applyFailsafeValue(uint8_t aux, uint16_t fs)
{
  if (aux < 16) return aux; // Extra/Relative : ne pas modifier
#if SPCM_FAILSAFE_ENABLED
  return makeFailsafeAux(aux, fs);
#else
  (void)fs;
  return aux & 0x1C;        // blocage compile-time : HOLD/OFF
#endif
}

static void setFailsafeUs(uint8_t ch, uint16_t us)
{
#if SPCM_FAILSAFE_ENABLED
  if (ch < 1 || ch > 8) return;
  us = constrain(us,900,2100);
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    FailsafeSpcm[ch-1] = failsafeUsToSpcm(us);
  }
#else
  (void)ch; (void)us;
#endif
}

static void setFailsafeOff(uint8_t ch)
{
  if (ch < 1 || ch > 8) return;
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    FailsafeSpcm[ch-1] = 0;
  }
}

static void buildLogicalFrame(uint8_t q[32], uint32_t frameNumber,
                              const uint16_t chUs[8], uint16_t ch9Us, uint16_t ch10Us,
                              const uint16_t fs[8])
{
  memset(q,0,32);
  uint8_t s=frameNumber&7;

  q[0] =pgm_read_byte(&Service[s][0]);
  q[3] =pgm_read_byte(&Service[s][1]);
  q[8] =pgm_read_byte(&Service[s][2]);
  q[11]=pgm_read_byte(&Service[s][3]);
  q[18]=pgm_read_byte(&Service[s][4]);
  q[21]=pgm_read_byte(&Service[s][5]);
  q[26]=pgm_read_byte(&Service[s][6]);
  q[29]=pgm_read_byte(&Service[s][7]);

  // Mapping FS identique a la version ESP32 validee :
  // AUX1->C1, AUX2->C2, AUX3->C3, AUX4->C4,
  // AUX5->C5, AUX6->C6, AUX7->C7, AUX8->C8.
  q[0] =applyFailsafeValue(q[0], fs[0]);
  q[18]=applyFailsafeValue(q[18],fs[1]);
  q[3] =applyFailsafeValue(q[3], fs[2]);
  q[21]=applyFailsafeValue(q[21],fs[3]);
  q[8] =applyFailsafeValue(q[8], fs[4]);
  q[26]=applyFailsafeValue(q[26],fs[5]);
  q[11]=applyFailsafeValue(q[11],fs[6]);
  q[29]=applyFailsafeValue(q[29],fs[7]);

  // C9 primaire AUX1/AUX3
  const uint8_t ch9=usToSpcmHighChannel(ch9Us);
  if (q[0]<16 && q[3]<16) {
    q[0]=(ch9>>4)&0x0F;
    q[3]=ch9&0x0F;
  }

  // C10 primaire AUX2/AUX4
  const uint8_t ch10=usToSpcmHighChannel(ch10Us);
  if (q[18]<16 && q[21]<16) {
    q[18]=(ch10>>4)&0x0F;
    q[21]=ch10&0x0F;
  }

  setSpcmChannel(q,16,usToSpcm(chUs[0]));
  setSpcmChannel(q, 1,usToSpcm(chUs[1]));
  setSpcmChannel(q,19,usToSpcm(chUs[2]));
  setSpcmChannel(q, 4,usToSpcm(chUs[3]));
  setSpcmChannel(q,24,usToSpcm(chUs[4]));
  setSpcmChannel(q, 9,usToSpcm(chUs[5]));
  setSpcmChannel(q,27,usToSpcm(chUs[6]));
  setSpcmChannel(q,12,usToSpcm(chUs[7]));

  makeCtrl(q, 0, 6,3,0x31);
  makeCtrl(q, 8,14,3,0x13);
  makeCtrl(q,16,22,3,0x91);
  makeCtrl(q,24,30,3,0x19);
}

static void makePhysicalBits(const uint8_t q[32], uint8_t bits[32])
{
  // 256 bits ranges directement en 32 octets, MSB d'abord.
  for (uint8_t n=0;n<32;n++)
    bits[n]=pgm_read_byte(&QuintetToPhysical[q[n]&0x1F]);
}

// -----------------------------------------------------------------------------
// Moteur Timer1 calque sur OpenAVRc / PROTO_PCM.cpp
//
// ATmega2560 : D12 = PB6 = OC1B
// Timer1 /8  : 2 MHz, 1 count = 0.5 us
// OC1B est en mode TOGGLE : le front SPCM est donc produit par le HARDWARE
// exactement au compare match. L'ISR ne fait que programmer OCR1B suivant.
//
// Comme dans OpenAVRc : OCR1B += duree ; jamais TCNT1 + duree.
// Le double buffer est construit hors ISR (il deviendra ensuite le travail PT).
// -----------------------------------------------------------------------------
static constexpr uint16_t SYNC_COUNTS  = 830;       // 415.0 us
static constexpr uint32_t FRAME_COUNTS = 88050UL;   // 44.025 ms
static constexpr uint16_t MAX_DURATIONS = 260;

// Une entree = duree entre deux VRAIES transitions SPCM, en demi-us.
static uint16_t DurationBuf[2][MAX_DURATIONS];
static volatile uint16_t DurationCount[2] = {0,0};
static volatile uint8_t  ActiveBuf = 0;
static volatile uint8_t  PendingBuf = 1;
static volatile bool     PendingReady = false;
static volatile uint16_t TxDurationIdx = 0;

// Tick SPCM valide ESP32 = 166.4 us = 332.8 counts Timer1 /8.
// Calcul par offset absolu : pas de derive cumulative.
static inline uint32_t ticksToCounts(uint16_t ticks)
{
  return ((uint32_t)ticks * 3328UL + 5UL) / 10UL;
}

// Construit EXACTEMENT les memes instants de transition que le code ESP32 valide.
// Le niveau n'est plus stocke : OC1B bascule materiellement a chaque compare.
// La derniere duree ramene exactement au debut de la trame suivante (44.025 ms).
static uint16_t buildDurations(const uint8_t physical[32], uint16_t *dst)
{
  uint32_t transition[MAX_DURATIONS];
  uint16_t n = 0;
  uint16_t ones = 0;

  // Fin du SYNC : premiere transition apres le debut de trame.
  transition[n++] = SYNC_COUNTS;

  // ESP32 valide : transition pour chaque bit physique a 1,
  // a SYNC + (i+1)*166.4 us.
  for (uint16_t i=0; i<256; i++) {
    const uint8_t byte = physical[i >> 3];
    if (!(byte & (0x80 >> (i & 7)))) continue;
    ones++;
    transition[n++] = (uint32_t)SYNC_COUNTS + ticksToCounts(i + 1);
  }

  // EOF identique a l'ESP32 valide.
  if ((ones & 1) == 0) {
    transition[n++] = (uint32_t)SYNC_COUNTS + ticksToCounts(258);
    transition[n++] = (uint32_t)SYNC_COUNTS + ticksToCounts(260);
  } else {
    transition[n++] = (uint32_t)SYNC_COUNTS + ticksToCounts(260);
  }

  // A partir du compare qui DEMARRE la trame, chaque entree indique
  // le temps jusqu'au prochain front.
  uint32_t previous = 0;
  uint16_t out = 0;
  for (uint16_t i=0; i<n; i++) {
    const uint32_t d = transition[i] - previous;
    if (d == 0 || d > 65535UL) return 0; // ne doit jamais arriver en SPCM /8
    dst[out++] = (uint16_t)d;
    previous = transition[i];
  }

  // Dernier intervalle : padding jusqu'au DEBUT de la trame suivante.
  const uint32_t pad = FRAME_COUNTS - previous;
  if (pad == 0 || pad > 65535UL) return 0;
  dst[out++] = (uint16_t)pad;
  return out;
}

// ISR volontairement tres courte, sur le principe de PROTO_PCM_cb1().
// IMPORTANT : lorsque cette ISR commence, PB6/OC1B a DEJA bascule en hardware.
ISR(TIMER1_COMPB_vect)
{
  uint8_t a = ActiveBuf;
  uint16_t idx = TxDurationIdx;

  // idx designe la duree a programmer APRES le front qui vient d'avoir lieu.
  if (idx >= DurationCount[a]) {
    // Le front qui vient d'avoir lieu est le debut de la trame suivante.
    // On bascule alors sur le buffer prepare, comme OpenAVRc.
    if (PendingReady) {
      ActiveBuf = PendingBuf;
      PendingReady = false;
      BufferSwapCount++;
    }
    FrameNumber++;
    a = ActiveBuf;
    idx = 0;
  }

  // Base de temps absolue du compare precedent : aucune accumulation
  // de la latence ISR dans le signal, exactement comme OpenAVRc.
  OCR1B += DurationBuf[a][idx];
  TxDurationIdx = idx + 1;
}

// -----------------------------------------------------------------------------
// Protothread de construction de la prochaine trame.
//
// IMPORTANT:
//   - le moteur Timer1 / OC1B valide n'est PAS modifie;
//   - l'ISR continue uniquement a programmer OCR1B += duree;
//   - le PT construit le buffer INACTIF;
//   - toutes les donnees qui doivent survivre a un PT_YIELD sont dans GraPtCtx;
//   - aucune variable locale automatique n'est utilisee apres un yield.
//
// Le decoupage par blocs de 16 bits physiques permet de rendre rapidement la
// main. C'est volontairement proche du principe OpenAVRc, tout en conservant
// ici le moteur V11 valide comme reference temporelle.
// -----------------------------------------------------------------------------
#define GRA_PT_BITS_PER_SLICE 16

typedef struct {
  uint8_t target;
  uint16_t ch[8];
  uint16_t c9;
  uint16_t c10;
  uint16_t fs[8];
  uint32_t fn;

  uint8_t q[32];
  uint8_t physical[32];

  uint16_t bitIndex;
  uint16_t ones;
  uint32_t previous;
  uint16_t out;
  bool abortBuild;

  // Etat persistant du builder de durees FULL-PT.
  // bitIndex / ones / previous existent deja ci-dessus dans le contexte PT4.
  // transition et delta completent l'etat necessaire entre deux PT_YIELD().
  uint32_t transition;
  uint32_t delta;
} GraPtCtx_t;

static GraPtCtx_t GraPtCtx;
static struct pt GraPcmPt;
static uint32_t PtPublishCount = 0;

static PT_THREAD(GraBuildNextFramePt(struct pt *pt))
{
  PT_BEGIN(pt);

  while (1) {
    PT_WAIT_UNTIL(pt, !PendingReady);

    // Snapshot atomique de la prochaine trame.
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
      GraPtCtx.target = ActiveBuf ^ 1;
      GraPtCtx.fn = FrameNumber + 1;

      for (uint8_t i=0; i<8; i++) {
        GraPtCtx.ch[i] = ChannelUs[i];
        GraPtCtx.fs[i] = FailsafeSpcm[i];
      }
      GraPtCtx.c9  = Channel9Us;
      GraPtCtx.c10 = Channel10Us;
    }

    buildLogicalFrame(GraPtCtx.q, GraPtCtx.fn,
                      GraPtCtx.ch, GraPtCtx.c9, GraPtCtx.c10, GraPtCtx.fs);
    PT_YIELD(pt);

    makePhysicalBits(GraPtCtx.q, GraPtCtx.physical);
    PT_YIELD(pt);

    // ----- buildDurations() incremental -----
    // Reproduit l'algorithme V11 valide, mais l'etat est dans GraPtCtx.
    GraPtCtx.out = 0;
    GraPtCtx.ones = 0;
    GraPtCtx.bitIndex = 0;
    GraPtCtx.previous = SYNC_COUNTS;

    DurationBuf[GraPtCtx.target][GraPtCtx.out++] = SYNC_COUNTS;

    while (GraPtCtx.bitIndex < 256) {
      // Chercher le prochain bit physique a 1.
      while (GraPtCtx.bitIndex < 256 &&
             !(GraPtCtx.physical[GraPtCtx.bitIndex >> 3] &
               (0x80 >> (GraPtCtx.bitIndex & 7)))) {
        GraPtCtx.bitIndex++;
      }

      if (GraPtCtx.bitIndex < 256) {
        GraPtCtx.ones++;

        GraPtCtx.transition =
            (uint32_t)SYNC_COUNTS + ticksToCounts(GraPtCtx.bitIndex + 1);
        GraPtCtx.delta = GraPtCtx.transition - GraPtCtx.previous;

        if (GraPtCtx.delta == 0 ||
            GraPtCtx.delta > 65535UL ||
            GraPtCtx.out >= (MAX_DURATIONS - 3)) {
          GraPtCtx.out = 0;
          break;
        }

        DurationBuf[GraPtCtx.target][GraPtCtx.out++] =
            (uint16_t)GraPtCtx.delta;
        GraPtCtx.previous = GraPtCtx.transition;
        GraPtCtx.bitIndex++;

        // FULL PT: une transition par tranche cooperative.
        PT_YIELD(pt);
      }
    }

    // EOF / parite identiques au builder V11.
    if (GraPtCtx.out) {
      if ((GraPtCtx.ones & 1) == 0) {
        GraPtCtx.transition =
            (uint32_t)SYNC_COUNTS + ticksToCounts(258);
        GraPtCtx.delta = GraPtCtx.transition - GraPtCtx.previous;

        if (GraPtCtx.delta && GraPtCtx.delta <= 65535UL &&
            GraPtCtx.out < MAX_DURATIONS) {
          DurationBuf[GraPtCtx.target][GraPtCtx.out++] =
              (uint16_t)GraPtCtx.delta;
          GraPtCtx.previous = GraPtCtx.transition;
        } else {
          GraPtCtx.out = 0;
        }

        if (GraPtCtx.out) {
          GraPtCtx.transition =
              (uint32_t)SYNC_COUNTS + ticksToCounts(260);
          GraPtCtx.delta = GraPtCtx.transition - GraPtCtx.previous;

          if (GraPtCtx.delta && GraPtCtx.delta <= 65535UL &&
              GraPtCtx.out < MAX_DURATIONS) {
            DurationBuf[GraPtCtx.target][GraPtCtx.out++] =
                (uint16_t)GraPtCtx.delta;
            GraPtCtx.previous = GraPtCtx.transition;
          } else {
            GraPtCtx.out = 0;
          }
        }
      } else {
        GraPtCtx.transition =
            (uint32_t)SYNC_COUNTS + ticksToCounts(260);
        GraPtCtx.delta = GraPtCtx.transition - GraPtCtx.previous;

        if (GraPtCtx.delta && GraPtCtx.delta <= 65535UL &&
            GraPtCtx.out < MAX_DURATIONS) {
          DurationBuf[GraPtCtx.target][GraPtCtx.out++] =
              (uint16_t)GraPtCtx.delta;
          GraPtCtx.previous = GraPtCtx.transition;
        } else {
          GraPtCtx.out = 0;
        }
      }
    }

    // Completer exactement a FRAME_COUNTS.
    if (GraPtCtx.out) {
      GraPtCtx.delta = FRAME_COUNTS - GraPtCtx.previous;

      if (GraPtCtx.delta && GraPtCtx.delta <= 65535UL &&
          GraPtCtx.out < MAX_DURATIONS) {
        DurationBuf[GraPtCtx.target][GraPtCtx.out++] =
            (uint16_t)GraPtCtx.delta;
      } else {
        GraPtCtx.out = 0;
      }
    }

    // Publication atomique du buffer complet.
    if (GraPtCtx.out) {
      ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
        DurationCount[GraPtCtx.target] = GraPtCtx.out;
        PendingBuf = GraPtCtx.target;
        PendingReady = true;
        PtPublishCount++;
      }
    }

    // Ne jamais reconstruire tant que l'ISR n'a pas pris le buffer.
    PT_WAIT_UNTIL(pt, !PendingReady);
  }

  PT_END(pt);
}

static void startSpcm()
{
  uint16_t ch[8], fs[8];
  for (uint8_t i=0; i<8; i++) {
    ch[i] = ChannelUs[i];
    fs[i] = FailsafeSpcm[i];
  }

  uint8_t q[32], physical[32];
  buildLogicalFrame(q, 0, ch, Channel9Us, Channel10Us, fs);
  makePhysicalBits(q, physical);
  DurationCount[0] = buildDurations(physical, DurationBuf[0]);

  ActiveBuf = 0;
  PendingBuf = 1;
  PendingReady = false;
  TxDurationIdx = 0;
  FrameNumber = 0;

  // Le premier buffer est construit classiquement pour garantir un demarrage
  // identique a la V11 validee. Le PT ne construit que les buffers suivants.
  PT_INIT(&GraPcmPt);

  cli();

  // OpenAVRc initialise OC1B par un Force Output Compare, puis passe en TOGGLE.
  // Avec le BC547, GPIO HIGH = transistor ON = ligne SPCM LOW (repos logique 0).
  DDRB |= SPCM_BIT;
  PORTB |= SPCM_BIT;

  // Timer1 identique OpenAVRc : mode normal, prescaler /8 = 2 MHz.
  TCCR1A = 0;
  TCCR1B = 0;
  TCCR1C = 0;
  TCNT1 = 0;

  // Force OC1B LOW au niveau broche MCU, puis TOGGLE sur chaque compare.
  // Nous voulons toutefois commencer avec PB6 HIGH (BC547 ON). Pour que le
  // premier compare demarre le SYNC en mettant PB6 LOW, on force d'abord HIGH
  // via SET, puis on active TOGGLE.
  TCCR1A = _BV(COM1B1) | _BV(COM1B0); // SET OC1B on forced compare
  TCCR1C = _BV(FOC1B);
  TCCR1A = _BV(COM1B0);               // TOGGLE OC1B on compare match

  // Meme philosophie OpenAVRc : premier compare 300 us plus tard.
  // Ce premier compare bascule PB6 et marque le DEBUT exact de la trame/SYNC.
  OCR1B = TCNT1 + 600U;               // 300 us @ 2 MHz
  TIFR1 = _BV(OCF1B);
  TIMSK1 |= _BV(OCIE1B);
  TCCR1B = _BV(CS11);                 // /8

  sei();
}

// -----------------------------------------------------------------------------
// Console ATmega2560 (pas de printf inutile)
// -----------------------------------------------------------------------------
static void setChannelUs(uint8_t ch,uint16_t us)
{
  if (ch<1 || ch>8) return;
  us=constrain(us,900,2100);
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { ChannelUs[ch-1]=us; }
}

static void showChannels()
{
  Serial.println();
  Serial.println(F("========== GRAUPNER SPCM 2560 V11 =========="));
  Serial.println(F("CHANNELS"));
  for (uint8_t i=0;i<8;i++) {
    uint16_t v;
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { v=ChannelUs[i]; }
    Serial.print(F("  C")); Serial.print(i+1); Serial.print(F(" : "));
    Serial.print(v); Serial.print(F(" us  SPCM=")); Serial.println(usToSpcm(v));
  }
  uint16_t c9,c10;
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { c9=Channel9Us; c10=Channel10Us; }
  Serial.print(F("  C9 : ")); Serial.print(c9); Serial.print(F(" us  SPCM8=")); Serial.println(usToSpcmHighChannel(c9));
  Serial.print(F("  C10: ")); Serial.print(c10); Serial.print(F(" us  SPCM8=")); Serial.println(usToSpcmHighChannel(c10));
  Serial.print(F("SWEEP = ")); Serial.println(SweepEnabled?F("ON"):F("OFF"));
  uint32_t fnDiag, swapDiag;
  uint8_t activeDiag, pendingDiag;
  bool readyDiag;
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    fnDiag=FrameNumber; swapDiag=BufferSwapCount;
    activeDiag=ActiveBuf; pendingDiag=PendingBuf; readyDiag=PendingReady;
  }
  Serial.print(F("PT5 frame=")); Serial.print(fnDiag);
  Serial.print(F(" swaps=")); Serial.print(swapDiag);
  Serial.print(F(" publishes=")); Serial.print(PtPublishCount);
  Serial.print(F(" active=")); Serial.print(activeDiag);
  Serial.print(F(" pending=")); Serial.print(pendingDiag);
  Serial.print(F(" ready=")); Serial.println(readyDiag?1:0);
#if SPCM_FAILSAFE_ENABLED
  Serial.println(F("FAILSAFE = ENABLED"));
  for (uint8_t i=0;i<8;i++) {
    uint16_t fs;
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { fs=FailsafeSpcm[i]; }
    Serial.print(F("  FS")); Serial.print(i+1); Serial.print(F(" : "));
    if (!fs) Serial.println(F("HOLD/OFF"));
    else Serial.println(fs);
  }
#else
  Serial.println(F("FAILSAFE = BLOCKED by SPCM_FAILSAFE_ENABLED=0 -> HOLD/OFF"));
#endif
  Serial.println(F("============================================"));
}

static void showHelp()
{
  Serial.println();
  Serial.println(F("Commands:"));
  Serial.println(F("  Builder: PROTOTHREAD / double buffer"));
  Serial.println(F("  C1 1000 ... C10 2000"));
  Serial.println(F("  SWEEP ON"));
  Serial.println(F("  SWEEP OFF   (stop + C1..C8 -> 1500 us)"));
#if SPCM_FAILSAFE_ENABLED
  Serial.println(F("  FS1 1000 ... FS8 2000   set Fail-Safe"));
  Serial.println(F("  FH1 ... FH8             HOLD/OFF one channel"));
  Serial.println(F("  FHA                     HOLD/OFF C1..C8"));
#else
  Serial.println(F("  Fail-Safe commands BLOCKED (#define = 0)"));
#endif
  Serial.println(F("  N / NEUTRAL"));
  Serial.println(F("  SHOW"));
  Serial.println(F("  HELP / ?"));
}

static void processConsoleLine(char *line)
{
  // Nettoyage de la ligne console :
  // - supprime espaces/tabulations en debut et fin
  // - reduit les espaces multiples a un seul
  // Ainsi "SWEEP OFF", "sweep   off " etc. sont tous acceptes.
  while (*line==' ' || *line=='\t') line++;
  if (!*line) return;

  char *src=line;
  char *dst=line;
  bool pendingSpace=false;
  while (*src) {
    if (*src==' ' || *src=='\t') {
      pendingSpace=true;
    } else {
      if (pendingSpace && dst!=line) *dst++=' ';
      *dst++=*src;
      pendingSpace=false;
    }
    src++;
  }
  *dst=0;

  if (!strcasecmp(line,"SHOW")) { showChannels(); return; }
  if (!strcasecmp(line,"HELP") || !strcmp(line,"?")) { showHelp(); return; }

  // SWEEP : analyse par mots plutot que comparaison de la ligne complete.
  // Accepte SWEEP OFF, sweep off, espaces multiples, etc.
  if (!strncasecmp(line, "SWEEP", 5) && (line[5] == 0 || line[5] == ' ')) {
    char *arg = line + 5;
    while (*arg == ' ' || *arg == '\t') arg++;

    if (!strcasecmp(arg, "ON")) {
      SweepEnabled = true;
      SweepStartMs = millis();
      Serial.println(F("SWEEP ON - C1..C8 1000..2000 us"));
      return;
    }

    if (!strcasecmp(arg, "OFF")) {
      SweepEnabled = false;
      ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
        for (uint8_t i=0; i<8; i++) ChannelUs[i] = 1500;
      }
      Serial.println(F("SWEEP OFF - C1..C8 -> 1500 us"));
      return;
    }

    Serial.println(F("Syntax: SWEEP ON / SWEEP OFF"));
    return;
  }
  if (!strcasecmp(line,"N") || !strcasecmp(line,"NEUTRAL")) {
    SweepEnabled=false;
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
      for (uint8_t i=0;i<8;i++) ChannelUs[i]=1500;
      Channel9Us=1500; Channel10Us=1500;
    }
    Serial.println(F("C1..C10 -> 1500 us")); return;
  }

  // Fail-Safe console.
  if (!strcasecmp(line,"FHA")) {
#if SPCM_FAILSAFE_ENABLED
    for (uint8_t ch=1; ch<=8; ch++) setFailsafeOff(ch);
    Serial.println(F("Fail-Safe C1..C8 -> HOLD/OFF"));
#else
    Serial.println(F("Fail-Safe BLOCKED by #define SPCM_FAILSAFE_ENABLED 0"));
#endif
    return;
  }

  if ((line[0]=='F' || line[0]=='f') && (line[1]=='H' || line[1]=='h')) {
#if SPCM_FAILSAFE_ENABLED
    char *end;
    long ch=strtol(line+2,&end,10);
    while (*end==' ' || *end=='\t') end++;
    if (ch<1 || ch>8 || *end) {
      Serial.println(F("Syntax: FH1 ... FH8"));
      return;
    }
    setFailsafeOff((uint8_t)ch);
    Serial.print(F("FS C")); Serial.print(ch); Serial.println(F(" -> HOLD/OFF"));
#else
    Serial.println(F("Fail-Safe BLOCKED by #define SPCM_FAILSAFE_ENABLED 0"));
#endif
    return;
  }

  if ((line[0]=='F' || line[0]=='f') && (line[1]=='S' || line[1]=='s')) {
#if SPCM_FAILSAFE_ENABLED
    char *end;
    long ch=strtol(line+2,&end,10);
    while (*end==' ' || *end=='\t') end++;
    if (ch<1 || ch>8 || !*end) {
      Serial.println(F("Syntax: FS1 1500 ... FS8 1500"));
      return;
    }
    char *endUs;
    long us=strtol(end,&endUs,10);
    while (*endUs==' ' || *endUs=='\t') endUs++;
    if (*endUs || us<900 || us>2100) {
      Serial.println(F("Fail-Safe range: 900..2100 us"));
      return;
    }
    setFailsafeUs((uint8_t)ch,(uint16_t)us);
    Serial.print(F("FS C")); Serial.print(ch); Serial.print(F(" = "));
    Serial.print(us); Serial.print(F(" us -> SPCM "));
    Serial.println(failsafeUsToSpcm((uint16_t)us));
#else
    Serial.println(F("Fail-Safe BLOCKED by #define SPCM_FAILSAFE_ENABLED 0"));
#endif
    return;
  }

  if (line[0]=='C' || line[0]=='c') {
    char *end;
    long ch=strtol(line+1,&end,10);
    while (*end==' ' || *end=='\t') end++;
    if (ch<1 || ch>10 || !*end) { Serial.println(F("Syntax: C1 1500 ... C10 1500")); return; }
    long us=strtol(end,nullptr,10);
    if (us<900 || us>2100) { Serial.println(F("Range: 900..2100 us")); return; }

    if (ch<=8) setChannelUs((uint8_t)ch,(uint16_t)us);
    else ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
      if (ch==9) Channel9Us=(uint16_t)us; else Channel10Us=(uint16_t)us;
    }
    Serial.print(F("C")); Serial.print(ch); Serial.print(F(" = ")); Serial.print(us); Serial.println(F(" us"));
    return;
  }

  Serial.println(F("Unknown command. Type HELP."));
}

static void consoleTask()
{
  static char line[48];
  static uint8_t pos=0;
  while (Serial.available()) {
    char c=(char)Serial.read();
    if (c=='\r' || c=='\n') {
      if (pos) { line[pos]=0; processConsoleLine(line); pos=0; }
    } else if (pos<sizeof(line)-1) line[pos++]=c;
  }
}

void setup()
{
  Serial.begin(115200);
  pinMode(SPCM_PIN,OUTPUT);
  digitalWrite(SPCM_PIN,HIGH); // BC547 ON -> ligne SPCM basse au repos
  delay(500);

  Serial.println();
  Serial.println(F("Graupner/JR SPCM 2560 V11 PT5 FULL-PT - FAILSAFE OPTION"));
  Serial.println(F("SPCM output: D12 / PB6 / OC1B (ATmega2560)"));
  showHelp();
  showChannels();

  startSpcm();
}

void loop()
{
  consoleTask();
  updateSweep();

  // PT5 FULL-PT : Timer1/OC1B reste totalement independant.
  // Une seule tranche cooperative par passage dans loop().
  // Le builder de durees lui-meme est maintenant decoupe par PT_YIELD().
  PT_SCHEDULE(GraBuildNextFramePt(&GraPcmPt));
}
