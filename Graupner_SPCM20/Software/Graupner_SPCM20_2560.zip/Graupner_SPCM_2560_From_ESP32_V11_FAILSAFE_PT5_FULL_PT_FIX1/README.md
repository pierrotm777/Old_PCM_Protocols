# PT5 FULL-PT FIX1

Correction de compilation de PT5:
- suppression des declarations dupliquees bitIndex, ones et previous dans GraPtCtx;
- conservation d'une seule instance de chacun;
- transition et delta restent ajoutes pour le builder FULL-PT;
- suppression de PtAbortCount devenu inutilise.

Aucune modification du moteur Timer1/OC1B ni de l'algorithme FULL-PT.
PT4 reste la reference stable.
