# Graupner SPCM 2560 V11 FAILSAFE PT

Experimental Protothreads adaptation of the validated Mega2560 V11 generator.

- Target: ATmega2560
- Output: D12 / PB6 / OC1B
- Timer1: /8, hardware OC1B toggle
- Timing ISR kept from the validated V11
- Real Adam Dunkels Protothreads files copied from OpenAVRc `thirdparty/pt`
- The PT only builds the inactive duration buffer
- C1..C10, SWEEP and optional FAILSAFE are preserved
- `SPCM_FAILSAFE_ENABLED` remains available
- Stable non-PT V11 is intentionally not modified

This is a test branch before integration into OpenAVRc.
