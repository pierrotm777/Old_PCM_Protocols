# RcSpcmRead

Décodeur **Graupner/JR SPCM 1024** pour Arduino AVR et ESP32.

Version **0.1.0** — première base de lecture construite à partir du protocole déjà validé avec `RcSpcmGen`.

> Cette version n'est pas encore déclarée validée matériellement en réception. Elle doit maintenant être testée sur un vrai signal MC-19 / module SPCM, à l'analyseur logique et avec les exemples fournis.

## Principe

La bibliothèque ne mesure pas le niveau logique du signal : elle mesure uniquement les **transitions** (`CHANGE`).

Cela a un avantage important : la polarité du signal n'a pas d'importance pour le décodage. Il n'y a donc pas de paramètre `INVERTED`.

Le signal SPCM doit cependant être **adapté électriquement au niveau logique du microcontrôleur**. Ne jamais injecter directement un signal 6 V / 10 V sur une entrée AVR ou ESP32.

## Synchronisation

Le flux SPCM comporte un SYNC d'environ **415 µs**.

Les transitions de données sont placées sur des multiples du tick SPCM d'environ **166,4 µs**. Le SYNC de 415 µs correspond à environ 2,5 ticks et constitue donc un marqueur très pratique : il ne peut pas être confondu avec un espacement normal de données de 1, 2, 3... ticks.

La bibliothèque détecte cet intervalle sur les changements d'état, puis reconstruit les 256 bits physiques de la trame suivante.

## Chaîne de décodage

```text
transitions électriques
        |
        v
détection du SYNC ~415 us
        |
        v
positionnement des transitions sur les ticks 166,4 us
        |
        v
256 bits physiques
        |
        v
32 octets physiques
        |
        v
inverse de QuintetToPhysical[]
        |
        v
32 quintets SPCM
        |
        v
validation CRC A/B/C/D
        |
        +--> C1..C8 10 bits
        +--> C9/C10 8 bits
        +--> fragments Fail-Safe
```

## CRC

Les quatre groupes sont validés avant publication des voies :

```text
A : 0x31
B : 0x13
C : 0x91
D : 0x19
```

Une trame dont un symbole physique ou un CRC est incorrect n'est pas publiée.

## Voies

C1 à C8 sont décodées sur 10 bits et converties en microsecondes avec
l'inverse de l'échelle SPCM absolue maintenant validée matériellement :

```text
SPCM 0    ->  900 us
SPCM 85   -> ~1000 us
SPCM 512  -> ~1500 us
SPCM 938  -> ~2000 us
SPCM 1023 -> 2100 us
```

L'ancienne interprétation `1000 -> 172 / 1500 -> 512 / 2000 -> 852`
était une échelle expérimentale et ne correspondait pas à la sortie PWM
réelle du récepteur. Elle est supprimée en v0.1.1.

C9 et C10 sont conservées entre deux occurrences, car les Extra Channels ne sont pas envoyés dans chaque trame.

## Fail-Safe

Les positions Fail-Safe C1..C8 sont reconstruites progressivement à partir des champs AUX de service.

Chaque position nécessite quatre fragments. Utiliser :

```cpp
RcSpcmRead.failsafeComplete(ch)
```

avant de considérer la valeur comme complète.

`failsafeUs(ch) == 0` signifie `HOLD/OFF`.

## Utilisation minimale

```cpp
#include <RcSpcmRead.h>

#define SPCM_IN_PIN 2

void setup()
{
    Serial.begin(115200);
    RcSpcmRead.begin(SPCM_IN_PIN);
}

void loop()
{
    if (RcSpcmRead.process()) {
        Serial.println(RcSpcmRead.channelUs(1));
    }
}
```

## Broches

Sur AVR, v0.1.0 utilise `attachInterrupt()`. La broche doit donc être compatible avec une interruption externe.

Exemples :

```text
Uno / Nano     : D2 ou D3
Mega2560       : D2, D3, D18, D19, D20 ou D21
ESP32          : GPIO adapté aux interruptions
```

Une version future pourra utiliser directement un périphérique de capture matérielle si les essais AVR montrent que cela apporte un bénéfice.

## API principale

```cpp
bool begin(uint8_t Pin);
void end();
bool process();

uint16_t channelUs(uint8_t Ch) const;
uint16_t channelRaw(uint8_t Ch) const;

bool signalValid(uint16_t TimeoutMs = 120) const;
uint32_t ageMs() const;

bool failsafeComplete(uint8_t Ch) const;
uint16_t failsafeUs(uint8_t Ch) const;
uint16_t failsafeRaw(uint8_t Ch) const;
void clearFailsafeDecode();

uint32_t validFrameCount() const;
uint32_t crcErrorCount() const;
uint32_t symbolErrorCount() const;
uint32_t timingErrorCount() const;
uint32_t droppedCaptureCount() const;
```

## Exemples

- `BasicMonitor` : affiche C1..C10.
- `Diagnostics` : compte les trames valides et les erreurs.
- `FailSafeMonitor` : reconstruit et affiche FS1..FS8.

## Première procédure de test conseillée

1. Commencer sur ESP32, où `micros()` et les interruptions GPIO offrent une bonne résolution.
2. Injecter le signal logique issu du générateur `RcSpcmGen` déjà validé.
3. Lancer `Diagnostics`.
4. Vérifier que `valid` augmente et que `crc`, `symbol` et `timing` restent proches de zéro.
5. Lancer ensuite un `SWEEP` sur le générateur et vérifier C1..C8 avec `BasicMonitor`.
6. Tester C9.
7. Programmer plusieurs positions Fail-Safe sur le générateur et contrôler leur reconstruction avec `FailSafeMonitor`.
8. Refaire exactement les mêmes tests sur ATmega2560.

Cette démarche permettra de valider la couche de capture avant d'ajouter d'autres fonctions.
