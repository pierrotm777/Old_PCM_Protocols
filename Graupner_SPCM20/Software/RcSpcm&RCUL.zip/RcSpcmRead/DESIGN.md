# RcSpcmRead decoder design notes

## Why edge timing is enough

RcSpcmGen generates an SPCM frame as a sequence of output toggles. After the frame-start edge, SYNC ends approximately 415 us later. Physical data transitions then occur at:

```text
SYNC_end + N * 166.4 us
```

where `N` is an integer physical-bit position from 1 to 256.

The termination/parity mechanism uses positions 258 and 260.

Because 415 us is approximately 2.5 SPCM ticks, it is distinct from legal data-to-data spacing. RcSpcmRead therefore detects the SYNC interval without needing to know whether the electrical signal is inverted.

## ISR responsibility

The interrupt handler intentionally does very little:

1. read `micros()`;
2. recognize the 415 us SYNC interval;
3. map each following edge to its closest SPCM tick;
4. set one bit in a 32-byte raw physical buffer;
5. publish that raw buffer at the next SYNC.

The ISR does **not**:

- search the physical symbol table;
- calculate CRC;
- decode channels;
- decode Fail-Safe.

Those operations are performed by `process()`.

## Buffering

Two 32-byte raw buffers are used.

One buffer receives edges while the other may be waiting for `process()`. If the application does not service `process()` fast enough, the next complete capture is dropped instead of overwriting the pending frame. `droppedCaptureCount()` reports this condition.

## Validation chain

A frame is published to the application only after:

1. all 32 physical bytes map to legal SPCM symbols;
2. all four CRC groups pass.

This is intentionally strict. A timing glitch cannot silently alter a servo channel without also passing both physical-symbol and CRC validation.
