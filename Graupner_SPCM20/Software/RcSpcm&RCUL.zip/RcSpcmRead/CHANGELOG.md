# Changelog

## 0.1.1 - 2026-10-06

- Corrected CH1..CH8 raw SPCM-to-microsecond conversion.
- Uses the hardware-validated absolute scale:
  0 -> 900 us, 512 -> ~1500 us, 1023 -> 2100 us.
- Fail-Safe display uses the same corrected inverse conversion.
- CH9/CH10 decoding, edge capture, symbol decoding and CRC validation
  are unchanged.

## 0.1.0 - 2026-10-06

- Initial Graupner/JR SPCM reader.
- AVR + ESP32 GPIO CHANGE-edge capture.
- Polarity-independent 415 us SYNC detection.
- 256-bit physical frame reconstruction.
- Inverse physical quintet decoding.
- Four-group CRC validation.
- CH1..CH8 10-bit decoding.
- CH9/CH10 8-bit Extra Channel decoding.
- CH1..CH8 Fail-Safe fragment reconstruction.
- Signal timeout and diagnostic counters.
- BasicMonitor, Diagnostics and FailSafeMonitor examples.
