#include "RcSpcmRead.h"
#include <string.h>

#if defined(ARDUINO_ARCH_AVR)
  #include <avr/interrupt.h>
#endif

/*
  Physical 8-bit code words used by Graupner/JR SPCM.

  The generator maps one 5-bit logical quintet to one of these 32 bytes.
  The reader performs the inverse lookup after reconstructing the 256-bit
  physical frame from edge timing.
*/
static const uint8_t QuintetToPhysical[32] =
{
    0x01,0x44,0x50,0x48,0x14,0x24,0x54,0x28,
    0x0A,0x42,0x09,0x41,0x12,0x22,0x11,0x21,
    0x02,0x04,0x40,0x20,0x51,0x08,0x52,0x10,
    0x45,0x25,0x05,0x15,0x49,0x29,0x4A,0x2A
};

RcSpcmReadClass *RcSpcmReadClass::_Instance = 0;
RcSpcmReadClass RcSpcmRead;

RcSpcmReadClass::RcSpcmReadClass()
{
    _Pin = 255;
    _Running = 0;

    memset(_ChannelRaw, 0, sizeof(_ChannelRaw));
    for(uint8_t i=0; i<RC_SPCM_READ_CHANNELS; ++i) _ChannelUs[i] = 1500;

    memset(_FailsafeRaw, 0, sizeof(_FailsafeRaw));
    memset(_FailsafeParts, 0, sizeof(_FailsafeParts));

    _LastValidMs = 0;
    _ValidFrames = 0;
    _CrcErrors = 0;
    _SymbolErrors = 0;

    memset((void*)_RawPhysical, 0, sizeof(_RawPhysical));
    _WriteBuf = 0;
    _ReadyBuf = 1;
    _RawReady = 0;

    _LastEdgeUs = 0;
    _SyncEndUs = 0;
    _LastTick = 0;
    _DataEdges = 0;
    _Capturing = 0;

    _TimingErrors = 0;
    _DroppedCaptures = 0;
}

bool RcSpcmReadClass::begin(uint8_t Pin)
{
    end();

    const int irq = digitalPinToInterrupt(Pin);
    if(irq == NOT_AN_INTERRUPT) return false;

    _Pin = Pin;
    pinMode(_Pin, INPUT);

    noInterrupts();
    _WriteBuf = 0;
    _ReadyBuf = 1;
    _RawReady = 0;
    _LastEdgeUs = micros();
    _SyncEndUs = 0;
    _LastTick = 0;
    _DataEdges = 0;
    _Capturing = 0;
    _TimingErrors = 0;
    _DroppedCaptures = 0;
    clearRawBuffer(0);
    clearRawBuffer(1);
    _Instance = this;
    _Running = 1;
    interrupts();

    attachInterrupt(irq, RcSpcmReadClass::isrThunk, CHANGE);
    return true;
}

void RcSpcmReadClass::end(void)
{
    if(_Pin != 255) {
        const int irq = digitalPinToInterrupt(_Pin);
        if(irq != NOT_AN_INTERRUPT) detachInterrupt(irq);
    }

    noInterrupts();
    _Running = 0;
    if(_Instance == this) _Instance = 0;
    interrupts();

    _Pin = 255;
}

#if defined(ARDUINO_ARCH_ESP32)
void IRAM_ATTR RcSpcmReadClass::isrThunk(void)
#else
void RcSpcmReadClass::isrThunk(void)
#endif
{
    if(_Instance) _Instance->onEdge();
}

void RcSpcmReadClass::clearRawBuffer(uint8_t idx)
{
    for(uint8_t i=0; i<32; ++i) _RawPhysical[idx][i] = 0;
}

void RcSpcmReadClass::onEdge(void)
{
    if(!_Running) return;

    const uint32_t now = micros();
    const uint32_t dt = now - _LastEdgeUs;
    _LastEdgeUs = now;

    /*
      Frame synchronization

      The electrical SPCM stream contains a nominal 415 us SYNC interval.
      Normal data transitions are placed on 166.4 us tick boundaries, so a
      ~415 us edge-to-edge interval is not a legal integer data-tick spacing.

      Therefore the end of SYNC can be detected from CHANGE edges alone.
      This also makes the reader independent of signal polarity.
    */
    if(dt >= RC_SPCM_READ_SYNC_MIN_US && dt <= RC_SPCM_READ_SYNC_MAX_US)
    {
        // The newly detected SYNC closes the previous captured frame.
        if(_Capturing && _DataEdges)
        {
            if(!_RawReady)
            {
                _ReadyBuf = _WriteBuf;
                _RawReady = 1;
                _WriteBuf ^= 1U;
            }
            else
            {
                // Main code has not consumed the previous raw frame yet.
                ++_DroppedCaptures;
            }
        }

        clearRawBuffer(_WriteBuf);
        _SyncEndUs = now;
        _LastTick = 0;
        _DataEdges = 0;
        _Capturing = 1;
        return;
    }

    if(!_Capturing) return;

    /*
      Convert absolute time since SYNC end into the closest 166.4 us tick.

      Data bits occupy ticks 1..256.
      The termination/parity transitions use ticks 258/260 and are ignored by
      the logical decoder, although their timing may still be observed here.
    */
    const uint32_t elapsed = now - _SyncEndUs;
    const uint16_t tick = roundTickFromUs(elapsed);

    if(tick < 1 || tick > 260) return;

    const uint32_t expected = tickToUs(tick);
    const uint32_t error = (elapsed >= expected) ? (elapsed - expected)
                                                  : (expected - elapsed);
    if(error > RC_SPCM_READ_TICK_TOLERANCE_US)
    {
        ++_TimingErrors;
        return;
    }

    // Reject repeated/backward timing points caused by glitches.
    if(tick <= _LastTick) {
        ++_TimingErrors;
        return;
    }
    _LastTick = tick;

    if(tick <= 256)
    {
        const uint16_t bitIndex = (uint16_t)(tick - 1U);
        _RawPhysical[_WriteBuf][bitIndex >> 3] |=
            (uint8_t)(0x80U >> (bitIndex & 7U));
        ++_DataEdges;
    }
}

bool RcSpcmReadClass::process(void)
{
    uint8_t physical[32];

    noInterrupts();
    if(!_RawReady)
    {
        interrupts();
        return false;
    }

    const uint8_t idx = _ReadyBuf;
    for(uint8_t i=0; i<32; ++i) physical[i] = _RawPhysical[idx][i];
    _RawReady = 0;
    interrupts();

    uint8_t q[32];

    if(!decodePhysical(physical, q))
    {
        ++_SymbolErrors;
        return false;
    }

    if(!validateCrc(q))
    {
        ++_CrcErrors;
        return false;
    }

    decodeChannels(q);
    decodeFailsafe(q);

    _LastValidMs = millis();
    ++_ValidFrames;
    return true;
}

int8_t RcSpcmReadClass::physicalToQuintet(uint8_t physical)
{
    for(uint8_t q=0; q<32; ++q)
        if(QuintetToPhysical[q] == physical) return (int8_t)q;
    return -1;
}

bool RcSpcmReadClass::decodePhysical(const uint8_t physical[32], uint8_t q[32])
{
    for(uint8_t i=0; i<32; ++i)
    {
        const int8_t v = physicalToQuintet(physical[i]);
        if(v < 0) return false;
        q[i] = (uint8_t)v;
    }
    return true;
}

uint8_t RcSpcmReadClass::crc8(const uint8_t data[4], uint8_t poly)
{
    uint8_t crc = 0;
    for(uint8_t n=0; n<4; ++n)
    {
        crc ^= data[n];
        for(uint8_t b=0; b<8; ++b)
            crc = (crc & 0x80U)
                ? (uint8_t)((crc << 1) ^ poly)
                : (uint8_t)(crc << 1);
    }
    return crc;
}

void RcSpcmReadClass::makeProtectedData(const uint8_t q[32], uint8_t Start,
                                        uint8_t CtrlHigh, uint8_t data[4])
{
    uint8_t bits[32];
    uint8_t p = 0;

    for(uint8_t n=0; n<6; ++n)
    {
        const uint8_t v = q[Start+n] & 0x1F;
        for(int8_t b=4; b>=0; --b) bits[p++] = (v >> b) & 1U;
    }

    bits[p++] = (CtrlHigh >> 1) & 1U;
    bits[p++] = CtrlHigh & 1U;

    for(uint8_t n=0; n<4; ++n)
    {
        uint8_t v = 0;
        for(uint8_t b=0; b<8; ++b)
            v = (uint8_t)((v << 1) | bits[n*8+b]);
        data[n] = v;
    }
}

bool RcSpcmReadClass::validateCrc(const uint8_t q[32]) const
{
    static const uint8_t starts[4]   = {0, 8, 16, 24};
    static const uint8_t ctrlPos[4]  = {6, 14, 22, 30};
    static const uint8_t polys[4]    = {0x31, 0x13, 0x91, 0x19};

    for(uint8_t g=0; g<4; ++g)
    {
        const uint16_t ctrl =
            ((uint16_t)(q[ctrlPos[g]] & 0x1F) << 5) |
             (uint16_t)(q[ctrlPos[g]+1] & 0x1F);

        const uint8_t ctrlHigh = (uint8_t)((ctrl >> 8) & 0x03);
        const uint8_t received = (uint8_t)(ctrl & 0xFF);

        uint8_t data[4];
        makeProtectedData(q, starts[g], ctrlHigh, data);

        if(crc8(data, polys[g]) != received) return false;
    }

    return true;
}

uint16_t RcSpcmReadClass::spcmToUs(uint16_t value)
{
    value &= 0x03FF;

    /*
      Inverse of the hardware-validated SPCM absolute-channel scale:

          0    ->  900 us
          512  -> ~1500 us
          1023 -> 2100 us

      Small +/-1 us differences are normal because the 1200 us servo span
      is quantized into 1024 protocol values.
    */
    return (uint16_t)(
        900UL + ((uint32_t)value * 1200UL + 511UL) / 1023UL
    );
}

uint16_t RcSpcmReadClass::highChannelToUs(uint8_t value)
{
    return (uint16_t)(900UL + ((uint32_t)value * 1200UL + 127UL) / 255UL);
}

void RcSpcmReadClass::decodeChannels(const uint8_t q[32])
{
    static const uint8_t pos[8] = {16, 1, 19, 4, 24, 9, 27, 12};

    for(uint8_t ch=0; ch<8; ++ch)
    {
        const uint8_t p = pos[ch];
        const uint16_t raw =
            ((uint16_t)(q[p] & 0x1F) << 5) |
             (uint16_t)(q[p+1] & 0x1F);

        _ChannelRaw[ch] = raw;
        _ChannelUs[ch] = spcmToUs(raw);
    }

    /*
      CH9 / CH10 Extra Channels.

      In the validated generator, CH9 uses AUX1+AUX3 and CH10 uses AUX2+AUX4
      when both AUX values are below 16. Service/Fail-Safe values are >=16.

      Extra channels are not present in every frame, so the last valid CH9/10
      value is retained until a new Extra Channel occurrence is received.
    */
    if(q[0] < 16 && q[3] < 16)
    {
        const uint8_t raw = (uint8_t)((q[0] << 4) | q[3]);
        _ChannelRaw[8] = raw;
        _ChannelUs[8] = highChannelToUs(raw);
    }

    if(q[18] < 16 && q[21] < 16)
    {
        const uint8_t raw = (uint8_t)((q[18] << 4) | q[21]);
        _ChannelRaw[9] = raw;
        _ChannelUs[9] = highChannelToUs(raw);
    }
}

void RcSpcmReadClass::decodeFailsafe(const uint8_t q[32])
{
    // AUX slot -> corresponding Fail-Safe channel.
    static const uint8_t auxPos[8] = {0, 18, 3, 21, 8, 26, 11, 29};

    for(uint8_t ch=0; ch<8; ++ch)
    {
        const uint8_t aux = q[auxPos[ch]];

        // Service/Fail-Safe encoding uses values 16..31.
        if(aux < 16) continue;

        const uint8_t base = aux & 0x1C;       // 16,20,24,28
        if(base < 16 || base > 28) continue;

        const uint8_t index = (uint8_t)((base >> 2) & 0x03);
        const uint8_t part = aux & 0x03;
        const uint8_t shift = (uint8_t)(2U + 2U * index);
        const uint16_t mask = (uint16_t)(0x03U << shift);

        _FailsafeRaw[ch] =
            (uint16_t)((_FailsafeRaw[ch] & ~mask) |
                       ((uint16_t)part << shift));

        _FailsafeParts[ch] |= (uint8_t)(1U << index);
    }
}

uint16_t RcSpcmReadClass::channelUs(uint8_t Ch) const
{
    if(Ch < 1 || Ch > RC_SPCM_READ_CHANNELS) return 0;
    return _ChannelUs[Ch-1];
}

uint16_t RcSpcmReadClass::channelRaw(uint8_t Ch) const
{
    if(Ch < 1 || Ch > RC_SPCM_READ_CHANNELS) return 0;
    return _ChannelRaw[Ch-1];
}

bool RcSpcmReadClass::signalValid(uint16_t TimeoutMs) const
{
    if(!_ValidFrames) return false;
    return (uint32_t)(millis() - _LastValidMs) <= (uint32_t)TimeoutMs;
}

uint32_t RcSpcmReadClass::ageMs(void) const
{
    if(!_ValidFrames) return 0xFFFFFFFFUL;
    return (uint32_t)(millis() - _LastValidMs);
}

bool RcSpcmReadClass::failsafeComplete(uint8_t Ch) const
{
    if(Ch < 1 || Ch > RC_SPCM_READ_FAILSAFE_CHANNELS) return false;
    return _FailsafeParts[Ch-1] == 0x0F;
}

uint16_t RcSpcmReadClass::failsafeRaw(uint8_t Ch) const
{
    if(Ch < 1 || Ch > RC_SPCM_READ_FAILSAFE_CHANNELS) return 0;
    return _FailsafeRaw[Ch-1] & 0x03FC;
}

uint16_t RcSpcmReadClass::failsafeUs(uint8_t Ch) const
{
    if(!failsafeComplete(Ch)) return 0;
    const uint16_t raw = failsafeRaw(Ch);

    // Protocol value zero means HOLD/OFF.
    if(raw == 0) return 0;
    return spcmToUs(raw);
}

void RcSpcmReadClass::clearFailsafeDecode(void)
{
    memset(_FailsafeRaw, 0, sizeof(_FailsafeRaw));
    memset(_FailsafeParts, 0, sizeof(_FailsafeParts));
}

uint16_t RcSpcmReadClass::roundTickFromUs(uint32_t elapsedUs)
{
    // round(elapsedUs / 166.4) == round(elapsedUs*10 / 1664)
    return (uint16_t)((elapsedUs * 10UL + 832UL) / 1664UL);
}

uint32_t RcSpcmReadClass::tickToUs(uint16_t tick)
{
    return ((uint32_t)tick * 1664UL + 5UL) / 10UL;
}
