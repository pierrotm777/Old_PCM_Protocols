/*
  RcSpcmRead - Graupner/JR SPCM 1024 decoder
  AVR + ESP32
  Version 0.1.1 - 2026-10-06

  This library decodes the electrical edge timing of a conditioned,
  logic-level SPCM signal. It reconstructs the 256 physical data bits,
  converts the 32 physical symbols back to SPCM quintets, validates all
  four CRC groups, and exposes CH1..CH10 plus transmitted Fail-Safe data.

  IMPORTANT:
  - The input MUST already be converted to a safe MCU logic level.
  - The decoder uses edge timing only, so signal polarity is irrelevant.
  - v0.1.0 is a first implementation based on the protocol/timing already
    validated by RcSpcmGen. It still needs hardware validation as a reader.
*/
#ifndef RCSPCMREAD_H
#define RCSPCMREAD_H

#include <Arduino.h>

#define RC_SPCM_READ_VERSION             "0.1.1"
#define RC_SPCM_READ_CHANNELS            10
#define RC_SPCM_READ_FAILSAFE_CHANNELS   8

// A genuine SPCM frame contains a 415 us SYNC pulse. Data transitions are
// located on multiples of the 166.4 us SPCM tick, so the 415 us interval is
// a convenient polarity-independent frame/sync marker.
#define RC_SPCM_READ_SYNC_MIN_US         370U
#define RC_SPCM_READ_SYNC_MAX_US         460U

// Maximum timing error accepted when assigning an edge to an SPCM tick.
// AVR micros() normally has 4 us granularity, therefore 32 us leaves ample
// margin while remaining far below half of a 166.4 us tick.
#define RC_SPCM_READ_TICK_TOLERANCE_US   32U

// Signal is considered lost if no CRC-valid frame has been decoded recently.
#define RC_SPCM_READ_DEFAULT_TIMEOUT_MS  120U

class RcSpcmReadClass
{
public:
    RcSpcmReadClass();

    /*
      Start edge capture on Pin.

      AVR:
        Pin must support attachInterrupt().
        Uno/Nano examples: D2 or D3.
        Mega2560 examples: D2, D3, D18, D19, D20 or D21.

      ESP32:
        Any suitable GPIO supporting GPIO interrupts may be used.

      The SPCM signal must already be limited/translated to the MCU voltage.
      Because decoding is based on CHANGE edges, no inversion option is needed.
    */
    bool begin(uint8_t Pin);
    void end(void);

    /*
      Decode one captured raw frame, if one is waiting.
      Return true only when a complete frame passes physical-symbol and CRC
      validation and the public channel values have been updated.

      Call process() frequently from loop().
    */
    bool process(void);

    // Most recently decoded servo position, channels 1..10.
    uint16_t channelUs(uint8_t Ch) const;
    uint16_t width_us(uint8_t Ch) const { return channelUs(Ch); }

    // Raw protocol value: CH1..CH8 = 10-bit, CH9/CH10 = 8-bit.
    uint16_t channelRaw(uint8_t Ch) const;

    // True while CRC-valid frames are still arriving.
    bool signalValid(uint16_t TimeoutMs = RC_SPCM_READ_DEFAULT_TIMEOUT_MS) const;
    uint32_t ageMs(void) const;

    /*
      Fail-Safe information carried by AUX Service fields.

      A complete Fail-Safe value is assembled over four service fragments.
      failsafeComplete(Ch) becomes true once all four fragments have been seen.

      failsafeUs(Ch):
        0    = HOLD/OFF
        >0   = decoded Fail-Safe position in microseconds
    */
    bool failsafeComplete(uint8_t Ch) const;
    uint16_t failsafeUs(uint8_t Ch) const;
    uint16_t failsafeRaw(uint8_t Ch) const;
    void clearFailsafeDecode(void);

    // Diagnostics.
    uint32_t validFrameCount(void) const { return _ValidFrames; }
    uint32_t crcErrorCount(void) const { return _CrcErrors; }
    uint32_t symbolErrorCount(void) const { return _SymbolErrors; }
    uint32_t timingErrorCount(void) const { return _TimingErrors; }
    uint32_t droppedCaptureCount(void) const { return _DroppedCaptures; }

    uint8_t isRunning(void) const { return _Running; }
    static const char *version(void) { return RC_SPCM_READ_VERSION; }

private:
    uint8_t _Pin;
    uint8_t _Running;

    // Publicly readable decoded state.
    uint16_t _ChannelRaw[RC_SPCM_READ_CHANNELS];
    uint16_t _ChannelUs[RC_SPCM_READ_CHANNELS];

    uint16_t _FailsafeRaw[RC_SPCM_READ_FAILSAFE_CHANNELS];
    uint8_t  _FailsafeParts[RC_SPCM_READ_FAILSAFE_CHANNELS];

    uint32_t _LastValidMs;
    uint32_t _ValidFrames;
    uint32_t _CrcErrors;
    uint32_t _SymbolErrors;

    /*
      ISR-side raw capture.

      Two 32-byte physical buffers are used. Each byte represents one encoded
      SPCM quintet. The ISR only timestamps edges and sets corresponding bits;
      all symbol lookup, CRC and channel decoding is done in process().
    */
    volatile uint8_t _RawPhysical[2][32];
    volatile uint8_t _WriteBuf;
    volatile uint8_t _ReadyBuf;
    volatile uint8_t _RawReady;

    volatile uint32_t _LastEdgeUs;
    volatile uint32_t _SyncEndUs;
    volatile uint16_t _LastTick;
    volatile uint16_t _DataEdges;
    volatile uint8_t _Capturing;

    volatile uint32_t _TimingErrors;
    volatile uint32_t _DroppedCaptures;

    static RcSpcmReadClass *_Instance;
    static void isrThunk(void);
    void onEdge(void);

    void clearRawBuffer(uint8_t idx);
    bool decodePhysical(const uint8_t physical[32], uint8_t q[32]);
    bool validateCrc(const uint8_t q[32]) const;
    void decodeChannels(const uint8_t q[32]);
    void decodeFailsafe(const uint8_t q[32]);

    static int8_t physicalToQuintet(uint8_t physical);
    static uint8_t crc8(const uint8_t data[4], uint8_t poly);
    static void makeProtectedData(const uint8_t q[32], uint8_t Start,
                                  uint8_t CtrlHigh, uint8_t data[4]);

    static uint16_t spcmToUs(uint16_t value);
    static uint16_t highChannelToUs(uint8_t value);
    static uint16_t roundTickFromUs(uint32_t elapsedUs);
    static uint32_t tickToUs(uint16_t tick);
};

extern RcSpcmReadClass RcSpcmRead;

#endif
