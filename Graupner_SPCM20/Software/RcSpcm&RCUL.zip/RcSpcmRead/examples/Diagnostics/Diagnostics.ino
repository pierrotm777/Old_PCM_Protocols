#include <RcSpcmRead.h>

#if defined(ARDUINO_ARCH_AVR)
  #define SPCM_IN_PIN 2
#else
  #define SPCM_IN_PIN 4
#endif

static uint32_t lastReport = 0;

void setup()
{
  Serial.begin(115200);
  delay(300);

  if (!RcSpcmRead.begin(SPCM_IN_PIN)) {
    Serial.println(F("ERROR: invalid interrupt pin"));
    while (1) {}
  }
}

void loop()
{
  RcSpcmRead.process();

  if (millis() - lastReport >= 1000) {
    lastReport = millis();

    Serial.print(F("SIGNAL="));
    Serial.print(RcSpcmRead.signalValid() ? F("OK") : F("LOST"));

    Serial.print(F(" valid="));
    Serial.print(RcSpcmRead.validFrameCount());

    Serial.print(F(" crc="));
    Serial.print(RcSpcmRead.crcErrorCount());

    Serial.print(F(" symbol="));
    Serial.print(RcSpcmRead.symbolErrorCount());

    Serial.print(F(" timing="));
    Serial.print(RcSpcmRead.timingErrorCount());

    Serial.print(F(" dropped="));
    Serial.println(RcSpcmRead.droppedCaptureCount());
  }
}
