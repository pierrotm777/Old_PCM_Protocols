#include <RcSpcmRead.h>

#if defined(ARDUINO_ARCH_AVR)
  #define SPCM_IN_PIN 2
#else
  #define SPCM_IN_PIN 4
#endif

static uint32_t lastPrint = 0;

void setup()
{
  Serial.begin(115200);
  delay(300);

  if (!RcSpcmRead.begin(SPCM_IN_PIN)) {
    Serial.println(F("RcSpcmRead.begin() FAILED"));
    while (1) {}
  }
}

void loop()
{
  RcSpcmRead.process();

  if (millis() - lastPrint >= 500) {
    lastPrint = millis();

    for (uint8_t ch = 1; ch <= 8; ++ch) {
      Serial.print(F("FS"));
      Serial.print(ch);
      Serial.print(F(": "));

      if (!RcSpcmRead.failsafeComplete(ch)) {
        Serial.print(F("learning"));
      } else {
        uint16_t fs = RcSpcmRead.failsafeUs(ch);
        if (fs == 0) Serial.print(F("HOLD/OFF"));
        else {
          Serial.print(fs);
          Serial.print(F(" us"));
        }
      }

      if (ch != 8) Serial.print(F(" | "));
    }
    Serial.println();
  }
}
