#include <RcSpcmRead.h>

#if defined(ARDUINO_ARCH_AVR)
  // Must be an external-interrupt pin.
  #define SPCM_IN_PIN 2
#else
  #define SPCM_IN_PIN 4
#endif

static uint32_t lastPrint = 0;

void setup()
{
  Serial.begin(115200);
  delay(300);

  if (!RcSpcmRead.begin(SPCM_IN_PIN)) {
    Serial.println(F("RcSpcmRead.begin() FAILED"));
    Serial.println(F("On AVR, choose a pin supported by attachInterrupt()."));
    while (1) {}
  }

  Serial.print(F("RcSpcmRead v"));
  Serial.println(RcSpcmRead.version());
}

void loop()
{
  RcSpcmRead.process();

  if (RcSpcmRead.signalValid() && millis() - lastPrint >= 100) {
    lastPrint = millis();

    for (uint8_t ch = 1; ch <= 10; ++ch) {
      Serial.print(F("C"));
      Serial.print(ch);
      Serial.print('=');
      Serial.print(RcSpcmRead.channelUs(ch));
      Serial.print(F("us "));
    }
    Serial.println();
  }
}
