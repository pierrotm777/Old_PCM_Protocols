# RcSpcmRead

**Graupner/JR SPCM 1024** decoder for Arduino AVR and ESP32.

Version **0.1.0** — first reader implementation derived from the protocol already validated with `RcSpcmGen`.

This version is intentionally marked as **not yet hardware-validated as a receiver**. The next step is testing against a real SPCM stream.

## Design

The decoder uses **CHANGE edge timing only**. Signal polarity therefore does not matter, but the input must already be translated to a safe MCU logic level.

A nominal **415 us SYNC** interval is detected between edges. Data transitions then map to multiples of the **166.4 us SPCM tick**. The decoder reconstructs the 256 physical data bits, performs the inverse physical-symbol lookup, validates all four CRC groups, and only then publishes channels.

## Supported data

- CH1..CH8: 10-bit absolute channels
- CH9/CH10: 8-bit Extra Channels
- CH1..CH8 transmitted Fail-Safe fragments
- CRC polynomials 0x31, 0x13, 0x91 and 0x19
- signal-valid timeout and diagnostic counters

## AVR input pins

v0.1.0 uses `attachInterrupt()`, so use an external-interrupt-capable pin.

Typical choices:

```text
Uno / Nano : D2 or D3
Mega2560   : D2, D3, D18, D19, D20 or D21
```

ESP32 may use a suitable GPIO interrupt pin.

See `README_FR.md` and the examples for more details.


## v0.1.1 channel-scale correction

CH1..CH8 now use the inverse of the hardware-validated SPCM absolute-channel
mapping:

```text
SPCM 0    ->  900 us
SPCM 512  -> ~1500 us
SPCM 1023 -> 2100 us
```

The older experimental 1000 us -> 172 / 1500 us -> 512 /
2000 us -> 852 interpretation has been removed. CH9/CH10 decoding is
unchanged. Fail-Safe values use the same corrected inverse conversion.
