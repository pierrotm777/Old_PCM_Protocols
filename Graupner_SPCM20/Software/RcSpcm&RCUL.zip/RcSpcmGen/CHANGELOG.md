# Changelog

## 0.5.2 - 2026-10-06

- Fixed native RCUL synchronization handling.
- `RculIsSynchro()` no longer calls/consumes `refresh()`.
- `process()` / `refresh()` service the SPCM generator explicitly.
- Each successful refresh latches one synchronization bit per RCUL client.
- `RculIsSynchro(ClientIdx)` clears only that client's bit.
- This fixes irregular symbol repetition when both `RcSpcmGen.process()` and
  `RcTxSerial::process()` are called in the same loop.
- Hardware validated with SW8 / XanySpy at 100% reception using
  `RCUL_REPEAT = 2`.
- No change to SPCM timing, CRC, Service/AUX, Fail-Safe or the v0.5.1
  900..2100 us absolute-channel scale.

## 0.5.1 - 2026-10-06

- Fixed CH1..CH8 microsecond-to-SPCM scaling.
- Restored the full absolute range: 900 us -> 0, 1500 us -> 512,
  2100 us -> 1023.
- Hardware validated at a real Graupner receiver PWM output.
- Restores the complete RCUL useful pulse range, including the low/high
  symbols around 1024 us and 1976 us.
- Fail-Safe continues to use the same normal conversion with the two low
  bits cleared as required by the SPCM Fail-Safe format.
- AVR FULL-PT timing, ESP32 timing, CRC, Service/AUX cycle and physical
  encoding are unchanged.
