#include <RcSpcmGen.h>

#if defined(__AVR_ATmega2560__)
  #define SPCM_PIN 12   // PB6 / OC1B
#else
  #define SPCM_PIN 10   // ATmega328P: PB2 / OC1B
#endif

void setup()
{
    Serial.begin(115200);
    if(!RcSpcmGen.begin(SPCM_PIN, RC_SPCM_INVERTED)) {
        Serial.println(F("RcSpcmGen begin FAILED"));
        return;
    }
    RcSpcmGen.setNeutral();
    RcSpcmGen.setChannelUs(1, 1000);
    RcSpcmGen.setChannelUs(2, 2000);
    RcSpcmGen.setAllFailsafeHold();
    RcSpcmGen.setFailsafeUs(1, 1500);

    Serial.print(F("RcSpcmGen AVR FULL-PT v"));
    Serial.println(RcSpcmGen.version());
    Serial.print(F("SPCM OC1B pin D")); Serial.println(SPCM_PIN);
    Serial.println(F("CH1=1000 CH2=2000 FS1=1500"));
}

void loop()
{
    RcSpcmGen.process();
}
