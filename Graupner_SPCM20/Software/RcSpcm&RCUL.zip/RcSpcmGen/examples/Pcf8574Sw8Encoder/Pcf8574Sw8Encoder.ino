/*
  RcSpcmGen + RcTxSerial + PCF8574
  =================================

  SW8 encoder example for AVR and ESP32.

  This example is derived from the validated
  RculI2cPotTx + RcTxSerial + PCF8574 project.

  The important change is simply that RcTxSerial now uses RcSpcmGen
  as its RCUL transport:

      static RcTxSerial MyRcTxSerial(
          &RcSpcmGen,
          RCUL_REPEAT,
          RCUL_FIFO_SIZE,
          RCUL_CHANNEL
      );

  RcSpcmGen therefore generates the Graupner/JR SPCM signal while
  RcTxSerial modulates one selected SPCM channel with the RCUL SW8 message.

  PCF8574 wiring
  --------------
      P0 ---- switch ---- GND
      P1 ---- switch ---- GND
      ...
      P7 ---- switch ---- GND

  PCF8574 pins are quasi-bidirectional.
  Writing 1 releases the pin so it can be used as an input.

      open switch   -> input HIGH -> logical SW = 0
      closed switch -> input LOW  -> logical SW = 1

  Default I2C address:
      PCF8574A = 0x38

  AVR SPCM output:
      ATmega328P / Uno / Nano : D10 = OC1B
      ATmega2560              : D12 = OC1B

  ESP32:
      SPCM output pin : GPIO1 by default
      SDA             : GPIO6
      SCL             : GPIO7

  IMPORTANT:
  RcSpcmGen AVR uses Timer1. Do not use Servo or another Timer1 library
  at the same time.

  The SPCM output polarity below is RC_SPCM_INVERTED, intended for the
  validated BC547 interface used with the Graupner HF module.
*/

#include <Arduino.h>
#include <Wire.h>
#include <Rcul.h>
#include <RcTxSerial.h>
#include <RcSpcmGen.h>

// ============================================================================
// Target-dependent pins
// ============================================================================

#if defined(__AVR_ATmega2560__)

  #define SPCM_PIN 12       // PB6 / OC1B

#elif defined(__AVR_ATmega328P__) || defined(__AVR_ATmega328__)

  #define SPCM_PIN 10       // PB2 / OC1B

#elif defined(ARDUINO_ARCH_ESP32)

  #define SPCM_PIN 1
  #define SDA_PIN  6
  #define SCL_PIN  7

#else
  #error "This example currently supports ATmega328(P), ATmega2560 and ESP32."
#endif

#define PRINT_BUF_SIZE   100
static char PrintBuf[PRINT_BUF_SIZE + 1];
#define PRINTF(fmt, ...)    do{if(Serial){snprintf_P(PrintBuf, PRINT_BUF_SIZE, PSTR(fmt) ,##__VA_ARGS__);Serial.print(PrintBuf);}}while(0)

// ============================================================================
// Debug Mode On/Off
// ============================================================================

bool DebugIsOn = false;
bool consoleMode = false;

// ============================================================================
// PCF8574
// ============================================================================

// PCF8574  : 0x20..0x27
// PCF8574A : 0x38..0x3F
#define PCF8574_ADDRESS  0x38
#define I2C_FREQUENCY    100000UL

static bool Pcf8574Connected = false;

// If the PCF8574 is absent, this value is transmitted instead.
// 0x00 = all SW8 switches OFF.
static uint8_t ManualContacts = 0x00;

// ============================================================================
// RCUL / RcTxSerial
// ============================================================================

// Same values as the reference SW8 encoder project.
static uint8_t RCUL_REPEAT = 2;

// CH3 carries the RCUL serial stream
static uint8_t RCUL_CHANNEL = 5;

#define RCUL_FIFO_SIZE  8

/*
  RcSpcmGen derives from Rcul, so it can directly replace RculI2cPotTx here.

  RcTxSerial will use:
    RculIsSynchro()
    RculGetWidth_us()
    RculSetWidth_us()

  implemented by RcSpcmGen.
*/
static RcTxSerial MyRcTxSerial(
    &RcSpcmGen,
    RCUL_REPEAT,
    RCUL_FIFO_SIZE,
    RCUL_CHANNEL
);

// Functions implemented in PCF8574.ino.
bool    Pcf8574Begin(void);
bool    Pcf8574Sample(void);
uint8_t Pcf8574Contacts(void);
uint8_t Pcf8574Address(void);

// ============================================================================
// Optional serial status
// ============================================================================

static uint32_t LastPrintMs = 0;

static void printHexByte(uint8_t v)
{
  if(v < 0x10) Serial.print('0');
  Serial.print(v, HEX);
}

void setup()
{
  Serial.begin(115200);

#if defined(ARDUINO_ARCH_ESP32)
  const uint32_t t0 = millis();
  while(!Serial && (uint32_t)(millis() - t0) < 1500UL)
    delay(1);
#else
  delay(300);
#endif

  Serial.println();
  Serial.println(F("****************************************"));
  Serial.println(F("RcSpcmGen + RcTxSerial + PCF8574 - SW8"));
  Serial.println(F("****************************************"));

  // --------------------------------------------------------------------------
  // Start SPCM generator.
  // --------------------------------------------------------------------------
  if(!RcSpcmGen.begin(SPCM_PIN, RC_SPCM_INVERTED))
  {
    Serial.println(F("RcSpcmGen.begin() FAILED"));

#if defined(ARDUINO_ARCH_AVR)
    Serial.println(F("AVR requires OC1B: D10 on ATmega328P, D12 on Mega2560."));
#endif

    while(1) { delay(1000); }
  }

  RcSpcmGen.setNeutral();

  Serial.print(F("RcSpcmGen v"));
  Serial.println(RcSpcmGen.version());

  Serial.print(F("SPCM OUT      : D/GPIO "));
  Serial.println(SPCM_PIN);

  Serial.print(F("RCUL channel  : CH"));
  Serial.println(RCUL_CHANNEL);

  Serial.print(F("RCUL repeats  : "));
  Serial.println(RCUL_REPEAT);

  // --------------------------------------------------------------------------
  // Start I2C bus.
  // --------------------------------------------------------------------------
#if defined(ARDUINO_ARCH_ESP32)
  Wire.begin(SDA_PIN, SCL_PIN);
  Serial.print(F("I2C SDA/SCL   : "));
  Serial.print(SDA_PIN);
  Serial.print('/');
  Serial.println(SCL_PIN);
#else
  // AVR uses the board's hardware I2C pins:
  // Uno/Nano A4/A5, Mega2560 D20/D21.
  Wire.begin();
#endif

  Wire.setClock(I2C_FREQUENCY);

  Pcf8574Connected = Pcf8574Begin();

  if(Pcf8574Connected)
  {
    Serial.print(F("PCF8574       : OK, address 0x"));
    Serial.println(Pcf8574Address(), HEX);

    Serial.print(F("Initial SW8    : 0x"));
    printHexByte(Pcf8574Contacts());
    Serial.println();
  }
  else
  {
    Serial.println(F("PCF8574       : NOT FOUND"));
    Serial.println(F("Fallback SW8  : 0x00"));
  }

  Serial.println();
}

void loop()
{
  processUsbConsole();
  
  /*
    Keep the same RcTxSerial sequence as the original
    RculI2cPotTx + PCF8574 project.

    When RcTxSerial is ready for a new RCUL message:
      1. sample the PCF8574 once;
      2. send one complete SW8 byte as two useful nibbles.

    The third argument = 1 keeps the historical RcTxSerial checksum mode
    used by the existing ATTiny / RCUL bridge.
  */
  if(MyRcTxSerial.isReadyForTx())
  {
    if(Pcf8574Connected && !Pcf8574Sample())
      Pcf8574Connected = false;

    uint8_t Message[1];

    Message[0] = Pcf8574Connected
               ? Pcf8574Contacts()
               : ManualContacts;

    MyRcTxSerial.sendNibbleMsg(Message, 2, 1);
  }

  /*
    RcSpcmGen v0.5.2 synchronization rule:

      1. RcSpcmGen.process() services the SPCM generator and, when a new
         frame/buffer is produced, latches one RCUL sync event per client.

      2. RcTxSerial::process() then consumes its own latched sync event through
         RcSpcmGen.RculIsSynchro(ClientIdx).

    IMPORTANT:
    RculIsSynchro() no longer calls refresh(), so the generator cannot steal
    the one-shot event from RcTxSerial. Keep this order in the main loop.
  */
  RcSpcmGen.process();
  RcTxSerial::process();

  // Optional low-rate status, useful on both AVR and ESP32.
  if((uint32_t)(millis() - LastPrintMs) >= 1000UL && DebugIsOn)
  {
    LastPrintMs = millis();

    Serial.print(F("SW8=0x"));
    printHexByte(Pcf8574Connected
               ? Pcf8574Contacts()
               : ManualContacts);

    Serial.print(F("  PCF="));
    Serial.print(Pcf8574Connected ? F("OK") : F("ERR"));

    Serial.print(F("  CH"));
    Serial.print(RCUL_CHANNEL);
    Serial.print('=');
    Serial.print(RcSpcmGen.channelUs(RCUL_CHANNEL));
    Serial.println(F(" us"));
  }
}
