/*
  PCF8574 - SW8 input
  ==================

  Shared source for AVR and ESP32.

  Wiring:
    P0 ---- switch ---- GND
    P1 ---- switch ---- GND
    ...
    P7 ---- switch ---- GND

  PCF8574 pins are quasi-bidirectional:
    writing 1 releases the pin so it can be used as an input.

  Therefore:
    open switch   -> input HIGH -> logical SW = 0
    closed switch -> input LOW  -> logical SW = 1
*/

static uint8_t PcfContacts = 0;
static bool    PcfReady = false;

static bool Pcf8574ReleaseInputs(void)
{
  Wire.beginTransmission(PCF8574_ADDRESS);
  Wire.write((uint8_t)0xFF);
  return Wire.endTransmission() == 0;
}

static bool Pcf8574Read(uint8_t &Value)
{
  const uint8_t Nb =
      Wire.requestFrom((uint8_t)PCF8574_ADDRESS, (uint8_t)1);

  if((Nb != 1U) || (Wire.available() < 1))
    return false;

  Value = (uint8_t)Wire.read();
  return true;
}

bool Pcf8574Begin(void)
{
  if(!Pcf8574ReleaseInputs())
  {
    PcfReady = false;
    return false;
  }

  uint8_t Raw = 0xFF;

  if(!Pcf8574Read(Raw))
  {
    PcfReady = false;
    return false;
  }

  // Active-low contacts -> active-high SW8 byte.
  PcfContacts = (uint8_t)~Raw;
  PcfReady = true;

  return true;
}

/*
  One-shot sample.

  As in the original project, the PCF8574 is read only when RcTxSerial
  is ready for the next message. This keeps I2C activity short and bounded.
*/
bool Pcf8574Sample(void)
{
  uint8_t Raw = 0xFF;

  if(!Pcf8574Read(Raw))
  {
    PcfReady = false;
    return false;
  }

  PcfContacts = (uint8_t)~Raw;
  PcfReady = true;
  return true;
}

uint8_t Pcf8574Contacts(void)
{
  return PcfContacts;
}

uint8_t Pcf8574Address(void)
{
  return PCF8574_ADDRESS;
}
