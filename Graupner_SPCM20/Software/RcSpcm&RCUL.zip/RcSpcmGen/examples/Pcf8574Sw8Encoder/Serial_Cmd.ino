void usbHelp(void)
{
  Serial.println(F("\r\nH    Help"));
  Serial.println(F("?        Read settings"));
  Serial.println(F("d        Debug On/Off"));
  Serial.println(F("ch <val> Define Channel number"));
  Serial.println(F("rn <val> Define Number of Repeats"));
  Serial.println(F("cv <hex> Set contacts manually (00-FF)"));
  Serial.println(F("q        Quit console mode\r\n"));
}

void readSettings(void)
{
  Serial.println(F("\r\noO Settings Oo\r\n"));
  PRINTF("Channel      : Use CH%d\r\n", RCUL_CHANNEL);
  PRINTF("PCF8574      : %s (Add: 0x%02X)\r\n", Pcf8574Connected ? "ON" : "OFF", Pcf8574Connected ? PCF8574_ADDRESS : 0);
  PRINTF("ContactNb    : %u\r\n", 8);
  PRINTF("Repeats      : %d\r\n", RCUL_REPEAT);
  Serial.println(F("----------------------------------------"));
  Serial.println(F("Payload      : SW8"));
  Serial.println(F("Nibbles  send: 2; MLEN=4"));
  Serial.println(F("----------------------------------------"));
}

static String usbLine;

static void processUsbConsole(void)
{
  while (Serial.available()) {
    const char c = (char)Serial.read();

    if (!consoleMode) {
      if (c == '\n') enterConsoleMode();
      continue;
    }

    if (c == '\r') continue;

    if (c == '\n') {
      usbHandleCmd(usbLine);
      usbLine = "";
    } else if (usbLine.length() < 120) {
      usbLine += c;
    }
  }
}

static void usbHandleCmd(String cmd)
{
  cmd.trim();
  if (!cmd.length()) return;

  const int separator = cmd.indexOf(' ');
  String op = separator < 0 ? cmd : cmd.substring(0, separator);
  String rest = separator < 0 ? "" : cmd.substring(separator + 1);
  op.toLowerCase();
  rest.trim();

  if (op == "q") { exitConsoleMode(); return; }
  if (op == "h") { usbHelp(); return; }
  if (op == "?") { readSettings(); return; }

  if (op == "d") {
      DebugIsOn = !DebugIsOn;
      PRINTF("Debug is %s\r\n", DebugIsOn ? "ON":"OFF");
    return;
  }

  if (op == "cv")
  {
      if (Pcf8574Connected)
      {
          Serial.println(F("Manual SW unavailable while expander is connected"));
          return;
      }

      char *EndPtr = nullptr;
      unsigned long Value = strtoul(rest.c_str(), &EndPtr, 16);

      if(rest.length() == 0 || EndPtr == rest.c_str() || *EndPtr != '\0' || Value > 0xFF)
      {
          Serial.println(F("Usage: cv <00-FF>"));
          return;
      }

      ManualContacts = (uint8_t)Value;

      Serial.print(F("Manual SW = 0x"));
      if(ManualContacts < 0x10) Serial.print('0');
      Serial.println(ManualContacts, HEX);
      return;
  }

  if (op == "ch") {
    const uint8_t value = (uint8_t)rest.toInt();
    if (value < 1 || value > 10) {
      Serial.print(F("Channel must be between 1 and 10"));
      return;
    }

    if (RCUL_CHANNEL != value)
    {
      RCUL_CHANNEL = value;
      MyRcTxSerial.setCh(RCUL_CHANNEL);
      PRINTF("Channel=%d\r\n", RCUL_CHANNEL);
    }
    return;
  }

  if (op == "rn") {
    const uint8_t value = (uint8_t)rest.toInt();
    if (value > 6) {
      Serial.print(F("Repeat must be between 0 and 6"));
      return;
    }

    if (RCUL_REPEAT != value)
    {
      RCUL_REPEAT = value;

      MyRcTxSerial.setRepeatNb(RCUL_REPEAT);
      PRINTF("Repeats=%d\r\n", RCUL_REPEAT);
    }
    return;
  }

  Serial.print(F("[USB] Unknown command. Type H."));
}

static void enterConsoleMode(void)
{
  consoleMode = true;
  Serial.println(F("\r\nConsole mode is Ready (H Help)"));
}

static void exitConsoleMode(void)
{
  consoleMode = false;
  Serial.print(F("\r\nQuit console mode\r\n"));
}

