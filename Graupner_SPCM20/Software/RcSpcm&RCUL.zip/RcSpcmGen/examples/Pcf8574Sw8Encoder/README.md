# Pcf8574Sw8Encoder

Example of an **SW8 RCUL encoder** using:

- `RcSpcmGen`
- `RcTxSerial`
- one `PCF8574` / `PCF8574A`
- AVR or ESP32

It is derived from the existing `RculI2cPotTx + RcTxSerial + PCF8574`
project. The transport object passed to `RcTxSerial` is simply replaced by
`RcSpcmGen`:

```cpp
static RcTxSerial MyRcTxSerial(
    &RcSpcmGen,
    RCUL_REPEAT,
    RCUL_FIFO_SIZE,
    RCUL_CHANNEL
);
```

## Default pins

### Arduino Uno / Nano / ATmega328P

- SPCM OUT: D10 / OC1B
- I2C: A4 SDA, A5 SCL

### Arduino Mega2560

- SPCM OUT: D12 / OC1B
- I2C: D20 SDA, D21 SCL

### ESP32

- SPCM OUT: GPIO1
- SDA: GPIO6
- SCL: GPIO7

Change the ESP32 pins at the top of the example if required.

## PCF8574

Default address is `0x38`, matching a PCF8574A with the address wiring used
in the reference project.

Each switch connects one P0..P7 pin to GND.

## RCUL payload

The example sends one complete SW8 byte:

```text
2 useful payload nibbles
MLEN = 4
```

The RCUL stream is placed on `CH5` by default.

The call is intentionally kept identical to the validated encoder project:

```cpp
MyRcTxSerial.sendNibbleMsg(Message, 2, 1);
```

The third parameter keeps the legacy checksum behavior expected by the
existing RCUL/ATTiny bridge.

## Dependencies

This example additionally requires the `RcTxSerial` library.

`RcSpcmGen` itself still only depends directly on `Rcul`.


## RcSpcmGen v0.5.2 process order

With v0.5.2 and later, the loop must explicitly service the SPCM generator
before servicing `RcTxSerial`:

```cpp
RcSpcmGen.process();
RcTxSerial::process();
```

`RcSpcmGen.process()` creates and latches the synchronization event.
`RcTxSerial::process()` consumes its own client bit through
`RculIsSynchro(ClientIdx)`.

This replaces the older behaviour where `RculIsSynchro()` called `refresh()`
directly. The older design could lose a synchronization event when both
process functions were called in the same loop.

Hardware validation: SW8 / XanySpy reached 100% reception with
`RCUL_REPEAT = 2`.
