#include <RcSpcmGen.h>

#if defined(__AVR_ATmega2560__)
  #define SPCM_PIN 12
#elif defined(ARDUINO_ARCH_AVR)
  #define SPCM_PIN 10
#else
  #define SPCM_PIN 1
#endif

void setup()
{
    Serial.begin(115200);

    // ESP32-S3: select CPU Frequency = 240 MHz with the current software engine.
    RcSpcmGen.begin(SPCM_PIN, RC_SPCM_INVERTED);

    // Normal positions while the RF link is present.
    RcSpcmGen.setNeutral();
    RcSpcmGen.setChannelUs(1, 1000);
    RcSpcmGen.setChannelUs(3, 1250);
    RcSpcmGen.setChannelUs(8, 2000);

    // HOLD/OFF is the default. Start from a known state, then program 3 FS positions.
    RcSpcmGen.setAllFailsafeHold();
    RcSpcmGen.setFailsafeUs(1, 1500);
    RcSpcmGen.setFailsafeUs(3, 1500);
    RcSpcmGen.setFailsafeUs(8, 1500);

    Serial.println(F("RcSpcmGen Fail-Safe demo"));
    Serial.println(F("RF OK   : CH1=1000, CH3=1250, CH8=2000 us"));
    Serial.println(F("RF lost : CH1/CH3/CH8 -> 1500 us"));
    Serial.println(F("Other Fail-Safe channels: HOLD/OFF"));
}

void loop()
{
    RcSpcmGen.process();
}
