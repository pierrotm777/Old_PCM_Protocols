#include <RcSpcmGen.h>

#define SPCM_PIN 10     // ATmega328P: PB2 / OC1B

void setup()
{
    Serial.begin(115200);
    if(!RcSpcmGen.begin(SPCM_PIN, RC_SPCM_INVERTED)) {
        Serial.println(F("RcSpcmGen begin FAILED: Uno requires D10 / OC1B"));
        return;
    }
    RcSpcmGen.setNeutral();
    RcSpcmGen.setChannelUs(1, 1000);
    RcSpcmGen.setChannelUs(2, 2000);
    RcSpcmGen.setAllFailsafeHold();
    RcSpcmGen.setFailsafeUs(1, 1500);
    Serial.println(F("RcSpcmGen AVR FULL-PT Uno test: SPCM on D10 / OC1B"));
}

void loop()
{
    RcSpcmGen.process();
}
