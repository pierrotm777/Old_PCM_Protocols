#include <RcSpcmGen.h>

#if defined(__AVR_ATmega2560__)
  #define SPCM_PIN 12
#elif defined(ARDUINO_ARCH_AVR)
  #define SPCM_PIN 10
#else
  #define SPCM_PIN 1
#endif

void setup()
{
    // ESP32-S3: the current software-timed engine was validated at 240 MHz.
    RcSpcmGen.begin(SPCM_PIN, RC_SPCM_INVERTED);
    RcSpcmGen.setNeutral();
    RcSpcmGen.setChannelUs(1, 1000);
}

void loop()
{
    // Must be called as often as possible when RCUL is not servicing the generator.
    RcSpcmGen.process();
}
