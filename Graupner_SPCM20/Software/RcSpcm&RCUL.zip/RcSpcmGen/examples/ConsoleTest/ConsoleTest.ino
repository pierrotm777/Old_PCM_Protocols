#include <RcSpcmGen.h>
#include <string.h>

#if defined(__AVR_ATmega2560__)
  #define SPCM_PIN 12
#elif defined(ARDUINO_ARCH_AVR)
  #define SPCM_PIN 10
#else
  #define SPCM_PIN 1
#endif

static char lineBuf[40];
static uint8_t linePos = 0;
static bool sweepEnabled = false;
static uint32_t sweepStartMs = 0;

static void updateSweep()
{
    if (!sweepEnabled) return;
    const uint32_t now = millis() - sweepStartMs;

    // C1..C8: triangular sweep 1000..2000 us, phase shifted by 250 ms.
    for (uint8_t ch = 0; ch < 8; ++ch) {
        uint32_t t = (now + (uint32_t)ch * 250UL) % 4000UL;
        uint16_t us = (t < 2000UL)
                    ? (uint16_t)(1000UL + t / 2UL)
                    : (uint16_t)(2000UL - (t - 2000UL) / 2UL);
        RcSpcmGen.setChannelUs((uint8_t)(ch + 1U), us);
    }
}

static void showChannels()
{
    Serial.println(F("Channels:"));
    for (uint8_t ch = 1; ch <= 10; ++ch) {
        Serial.print(F("  CH")); Serial.print(ch); Serial.print(F(" = "));
        Serial.print(RcSpcmGen.channelUs(ch)); Serial.println(F(" us"));
    }
    Serial.print(F("SWEEP = ")); Serial.println(sweepEnabled ? F("ON") : F("OFF"));
    Serial.println(F("Fail-Safe:"));
    for (uint8_t ch = 1; ch <= 8; ++ch) {
        Serial.print(F("  FS")); Serial.print(ch); Serial.print(F(" = "));
        uint16_t fs = RcSpcmGen.getFailsafeUs(ch);
        if (fs == 0) Serial.println(F("HOLD/OFF"));
        else { Serial.print(fs); Serial.println(F(" us")); }
    }
}

static void help()
{
    Serial.println(F("C1 1000 .. C10 2000 : set channel (900..2100 us)"));
    Serial.println(F("FS1 1500 .. FS8 1500 : set Fail-Safe position"));
    Serial.println(F("FH1 .. FH8            : HOLD/OFF one Fail-Safe channel"));
    Serial.println(F("FHA                    : HOLD/OFF all Fail-Safe channels"));
    Serial.println(F("N                      : CH1..CH10 = 1500 us"));
    Serial.println(F("SWEEP ON | SWEEP OFF   : sweep CH1..CH8 (1000..2000 us)"));
    Serial.println(F("STOP                   : stop SPCM, keep CH/FS values"));
    Serial.println(F("START                  : restart SPCM cleanly at SYNC/frame 0"));
    Serial.println(F("SHOW | HELP"));
}

static void command(char *s)
{
    while (*s == ' ' || *s == '\t') ++s;

    if (!strcasecmp(s, "SHOW")) { showChannels(); return; }
    if (!strcasecmp(s, "STOP")) { RcSpcmGen.stop(); Serial.println(F("SPCM STOPPED")); return; }
    if (!strcasecmp(s, "START")) {
        if (RcSpcmGen.start()) Serial.println(F("SPCM STARTED at SYNC / Service frame 0"));
        else Serial.println(F("SPCM START failed"));
        return;
    }
    if (!strcasecmp(s, "HELP") || !strcmp(s, "?")) { help(); return; }
    if (!strcasecmp(s, "N")) { sweepEnabled=false; RcSpcmGen.setNeutral(); Serial.println(F("Neutral 1500 us")); return; }
    if (!strcasecmp(s, "SWEEP ON")) {
        sweepEnabled=true; sweepStartMs=millis();
        Serial.println(F("SWEEP ON")); return;
    }
    if (!strcasecmp(s, "SWEEP OFF")) {
        sweepEnabled=false;
        Serial.println(F("SWEEP OFF")); return;
    }
    if (!strcasecmp(s, "FHA")) { RcSpcmGen.setAllFailsafeHold(); Serial.println(F("FS1..FS8 = HOLD/OFF")); return; }

    if (!strncasecmp(s, "FH", 2)) {
        int ch = atoi(s + 2);
        if (ch >= 1 && ch <= 8) {
            RcSpcmGen.setFailsafeHold(ch);
            Serial.print(F("FS")); Serial.print(ch); Serial.println(F(" = HOLD/OFF"));
        } else Serial.println(F("FH channel: 1..8"));
        return;
    }

    if (!strncasecmp(s, "FS", 2)) {
        char *p = s + 2;
        int ch = atoi(p);
        while (*p >= '0' && *p <= '9') ++p;
        while (*p == ' ' || *p == '\t') ++p;
        int us = atoi(p);
        if (ch >= 1 && ch <= 8 && us >= 900 && us <= 2100) {
            RcSpcmGen.setFailsafeUs(ch, (uint16_t)us);
            Serial.print(F("FS")); Serial.print(ch); Serial.print(F(" = "));
            Serial.print(us); Serial.println(F(" us"));
        } else Serial.println(F("Usage: FS1 1500 (CH1..CH8, 900..2100 us)"));
        return;
    }

    if (s[0] == 'C' || s[0] == 'c') {
        char *p = s + 1;
        int ch = atoi(p);
        while (*p >= '0' && *p <= '9') ++p;
        while (*p == ' ' || *p == '\t') ++p;
        int us = atoi(p);
        if (ch >= 1 && ch <= 10 && us >= 900 && us <= 2100) {
            RcSpcmGen.setChannelUs(ch, (uint16_t)us);
            Serial.print(F("CH")); Serial.print(ch); Serial.print(F(" = "));
            Serial.print(us); Serial.println(F(" us"));
        } else Serial.println(F("Usage: C1 1500 (CH1..CH10, 900..2100 us)"));
        return;
    }
    Serial.println(F("Unknown command; type HELP"));
}

static void serialTask()
{
    while (Serial.available()) {
        char c = (char)Serial.read();
        if (c == '\r' || c == '\n') {
            if (linePos) {
                lineBuf[linePos] = 0;
                command(lineBuf);
                linePos = 0;
            }
        } else if (linePos < sizeof(lineBuf) - 1) {
            lineBuf[linePos++] = c;
        }
    }
}

void setup()
{
    Serial.begin(115200);
    delay(300);
#if defined(ARDUINO_ARCH_AVR)
    // Calibration measured on the Uno used for digital(10).csv.
    // Set to 0 for an uncalibrated board; each board may differ.
#endif
    if(!RcSpcmGen.begin(SPCM_PIN, RC_SPCM_INVERTED)) {
        Serial.println(F("RcSpcmGen begin FAILED (AVR requires OC1B: D10 on ATmega328P, D12 on Mega2560)"));
    }
    Serial.print(F("RcSpcmGen v")); Serial.println(RcSpcmGen.version());
#if defined(ARDUINO_ARCH_ESP32)
    Serial.println(F("ESP32-S3: CPU Frequency = 240 MHz required by current software-timed engine."));
#endif
    help();
}

void loop()
{
    RcSpcmGen.process();
    updateSweep();
    serialTask();
}
