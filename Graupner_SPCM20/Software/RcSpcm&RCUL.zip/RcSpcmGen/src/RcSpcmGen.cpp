#include "RcSpcmGen.h"
#include <string.h>
#if defined(ARDUINO_ARCH_AVR)
#include <avr/interrupt.h>
static RcSpcmGenClass *gRcSpcmGenAvr = 0;
ISR(TIMER1_COMPB_vect) { if(gRcSpcmGenAvr) gRcSpcmGenAvr->avrTimerIsr(); }
#endif

static const uint8_t QuintetToPhysical[32] =
{
    0x01,0x44,0x50,0x48,0x14,0x24,0x54,0x28,
    0x0A,0x42,0x09,0x41,0x12,0x22,0x11,0x21,
    0x02,0x04,0x40,0x20,0x51,0x08,0x52,0x10,
    0x45,0x25,0x05,0x15,0x49,0x29,0x4A,0x2A
};

// Service/AUX cycle recovered from the MC-19 reference capture.
// V10: Service/AUX cycle measured on the MC-19 with Fail-Safe enabled.
// Order: AUX1 AUX3 AUX5 AUX7 | AUX2 AUX4 AUX6 AUX8
static const uint8_t Service[8][8] =
{
    {28,28,24,24,  8, 0,28,20},
    { 8, 0,28,28, 28,16,16,24},
    {16,16,16,16,  8, 0,20,28},
    { 8, 0,20,20, 16,20,24,16},
    {20,20,24,24,  8, 0,28,20},
    { 8, 0,28,28, 20,24,16,24},
    {24,24,16,16,  8, 0,20,28},
    { 8, 0,20,20, 24,28,24,16}
};

RcSpcmGenClass RcSpcmGen;

RcSpcmGenClass::RcSpcmGenClass()
{
    _Pin = 255;
    _Inverted = RC_SPCM_INVERTED;
    _Running = 0;
    _FrameNumber = 0;
    _NextFrameUs = 0;
    _FramePeriodUs = RC_SPCM_DEFAULT_FRAME_US;
    _RculSynchro = 0;
#if defined(ARDUINO_ARCH_AVR)
    _AvrPort=0; _AvrMask=0;
    _AvrDurationCount[0]=_AvrDurationCount[1]=0;
    _AvrActiveBuf=0; _AvrPendingBuf=1; _AvrPendingReady=0;
    _AvrTxDurationIdx=0; _AvrTxFrameNumber=0;
    _AvrSyncCounts=0; _AvrFrameCounts=0;
    _AvrPublishCount=0;
    memset(_AvrDurationBuf,0,sizeof(_AvrDurationBuf));
    memset(&_AvrPtCtx,0,sizeof(_AvrPtCtx));
    PT_INIT(&_AvrPt);
#endif
    setNeutral();
    setAllFailsafeHold();
}

bool RcSpcmGenClass::begin(uint8_t Pin, uint8_t Inverted)
{
    const uint8_t firstBegin = (_Pin == 255);
    _Pin = Pin;
    _Inverted = !!Inverted;

#if defined(ARDUINO_ARCH_AVR)
    // Hardware OC1B is mandatory on the validated AVR backend.
  #if defined(__AVR_ATmega328P__) || defined(__AVR_ATmega328__)
    if(Pin != 10) { _Running=0; return false; } // PB2 / OC1B
  #elif defined(__AVR_ATmega2560__)
    if(Pin != 12) { _Running=0; return false; } // PB6 / OC1B
  #else
    _Running=0; return false;
  #endif
#endif

    pinMode(_Pin, OUTPUT);
#if defined(ARDUINO_ARCH_AVR)
    _AvrPort = portOutputRegister(digitalPinToPort(_Pin));
    _AvrMask = digitalPinToBitMask(_Pin);
#endif
    writePhysical(0);

    // Initial begin() starts neutral; START/re-begin preserves CH and FS values.
    if(firstBegin) setNeutral();
    _FrameNumber = 0;
    _NextFrameUs = micros();
    _RculSynchro = 0;
    _Running = 1;

#if defined(ARDUINO_ARCH_AVR)
    uint8_t sreg=SREG; cli();
    TIMSK1 &= (uint8_t)~_BV(OCIE1B);
    TCCR1A=0; TCCR1B=0; TCCR1C=0;
    TCNT1=0;
    TIFR1=_BV(OCF1B);

    _AvrDurationCount[0]=0;
    _AvrDurationCount[1]=0;
    _AvrActiveBuf=0;
    _AvrPendingBuf=1;
    _AvrPendingReady=0;
    _AvrTxDurationIdx=0;
    _AvrTxFrameNumber=0;
    _AvrPublishCount=0;
    memset(&_AvrPtCtx,0,sizeof(_AvrPtCtx));
    PT_INIT(&_AvrPt);
    gRcSpcmGenAvr=this;
    SREG=sreg;

    // Frame 0 is built synchronously. Following frames are built FULL-PT.
    avrStartTimer();
    if(!_Running) return false;
#endif
    return true;
}

void RcSpcmGenClass::end(void)
{
    _Running = 0;
    _RculSynchro = 0;
#if defined(ARDUINO_ARCH_AVR)
    uint8_t sreg=SREG; cli();
    TIMSK1 &= (uint8_t)~_BV(OCIE1B);
    TCCR1A &= (uint8_t)~(_BV(COM1B1)|_BV(COM1B0));
    TCCR1B = 0;
    gRcSpcmGenAvr = 0;
    SREG=sreg;
#endif
    if(_Pin != 255) writePhysical(0);
}

bool RcSpcmGenClass::start(void)
{
    if(_Pin == 255) return false;
    // Re-use the deterministic begin sequence with the stored electrical
    // configuration. Repeated begin() preserves channels and Fail-Safe.
    return begin(_Pin, _Inverted);
}

void RcSpcmGenClass::setNeutral(void)
{
    for(uint8_t i=0; i<RC_SPCM_CH_NB; ++i) _ChannelUs[i] = 1500;
}

void RcSpcmGenClass::setFailsafeUs(uint8_t Ch, uint16_t Width_us)
{
    if(Ch < 1 || Ch > RC_SPCM_FAILSAFE_CH_NB) return;
    if(Width_us < 900) Width_us = 900;
    if(Width_us > 2100) Width_us = 2100;
    uint16_t v = usToSpcm(Width_us) & 0x03FC;
#if defined(ARDUINO_ARCH_AVR)
    uint8_t sreg = SREG; cli();
    _FailsafeSpcm[Ch-1] = v;
    _FailsafeUs[Ch-1] = Width_us;
    SREG = sreg;
#else
    _FailsafeSpcm[Ch-1] = v;
    _FailsafeUs[Ch-1] = Width_us;
#endif
}

void RcSpcmGenClass::setFailsafeHold(uint8_t Ch)
{
    if(Ch < 1 || Ch > RC_SPCM_FAILSAFE_CH_NB) return;
#if defined(ARDUINO_ARCH_AVR)
    uint8_t sreg = SREG; cli();
    _FailsafeSpcm[Ch-1] = 0;
    _FailsafeUs[Ch-1] = 0;
    SREG = sreg;
#else
    _FailsafeSpcm[Ch-1] = 0;
    _FailsafeUs[Ch-1] = 0;
#endif
}

void RcSpcmGenClass::setAllFailsafeHold(void)
{
    for(uint8_t i=0; i<RC_SPCM_FAILSAFE_CH_NB; ++i) { _FailsafeSpcm[i] = 0; _FailsafeUs[i] = 0; }
}

uint16_t RcSpcmGenClass::getFailsafeUs(uint8_t Ch) const
{
    if(Ch < 1 || Ch > RC_SPCM_FAILSAFE_CH_NB) return 0;
#if defined(ARDUINO_ARCH_AVR)
    uint8_t sreg = SREG;
    cli();
    uint16_t v = _FailsafeUs[Ch-1];
    SREG = sreg;
    return v;
#else
    return _FailsafeUs[Ch-1];
#endif
}


void RcSpcmGenClass::width_us(uint8_t Ch, uint16_t Width_us)
{
    if(Ch < 1 || Ch > RC_SPCM_CH_NB) return;
    if(Width_us < 900) Width_us = 900;
    if(Width_us > 2100) Width_us = 2100;

#if defined(ARDUINO_ARCH_AVR)
    uint8_t sreg = SREG;
    cli();
    _ChannelUs[Ch-1] = Width_us;
    SREG = sreg;
#else
    _ChannelUs[Ch-1] = Width_us;
#endif
}

uint16_t RcSpcmGenClass::width_us(uint8_t Ch) const
{
    if(Ch < 1 || Ch > RC_SPCM_CH_NB) return 0;
#if defined(ARDUINO_ARCH_AVR)
    uint8_t sreg = SREG;
    cli();
    uint16_t v = _ChannelUs[Ch-1];
    SREG = sreg;
    return v;
#else
    return _ChannelUs[Ch-1];
#endif
}

uint8_t RcSpcmGenClass::RculIsSynchro(uint8_t ClientIdx)
{
    /*
      v0.5.2:
      RculIsSynchro() MUST NOT call refresh().

      The previous implementation returned refresh() directly. If a sketch
      also called RcSpcmGen.process(), whichever call happened first could
      consume the one-shot refresh event and RcTxSerial would miss a symbol
      update. This produced irregular RCUL symbol repetition counts and
      checksum/length errors at the receiver.

      refresh()/process() now latch one synchronization bit per RCUL client.
      Each client consumes only its own bit here.
    */
    if(ClientIdx >= 8U) return 0;

    const uint8_t mask = (uint8_t)(1U << ClientIdx);
    if((_RculSynchro & mask) == 0U) return 0;

    _RculSynchro &= (uint8_t)~mask;
    return 1;
}

uint16_t RcSpcmGenClass::RculGetWidth_us(uint8_t Ch)
{
    return width_us(Ch);
}

void RcSpcmGenClass::RculSetWidth_us(uint16_t Width_us, uint8_t Ch)
{
    width_us(Ch, Width_us);
}

void RcSpcmGenClass::writePhysical(uint8_t Level)
{
    // Validated BC547 interface:
    // logical HIGH -> GPIO LOW -> transistor OFF -> SPCM about +10 V
    // logical LOW  -> GPIO HIGH -> transistor ON  -> SPCM about 0 V
    uint8_t gpioLevel = _Inverted ? !Level : Level;
#if defined(ARDUINO_ARCH_AVR)
    // Direct PORT access: deterministic and works on ATmega328(P) and ATmega2560.
    if(_AvrPort) {
        if(gpioLevel) *_AvrPort |= _AvrMask;
        else          *_AvrPort &= (uint8_t)~_AvrMask;
    } else {
        digitalWrite(_Pin, gpioLevel ? HIGH : LOW);
    }
#else
    digitalWrite(_Pin, gpioLevel ? HIGH : LOW);
#endif
}

uint16_t RcSpcmGenClass::usToSpcm(uint16_t us)
{
    /*
      Hardware-validated SPCM absolute-channel scale:

          900 us  ->    0
         1000 us  ->   85
         1500 us  ->  512
         2000 us  ->  938
         2100 us  -> 1023

      The previous experimental 1000->172 / 1500->512 / 2000->852
      conversion compressed the real receiver output to about
      1100..1900 us. It is intentionally no longer used.

      SPCM absolute CH1..CH8 uses the complete 10-bit range 0..1023
      over approximately 900..2100 us.
    */
    if(us <= 900)  return 0;
    if(us >= 2100) return 1023;

    return (uint16_t)(
        ((uint32_t)(us - 900U) * 1023UL + 600UL) / 1200UL
    );
}

uint8_t RcSpcmGenClass::usToSpcmHighChannel(uint16_t us)
{
    if(us <= 900) return 0;
    if(us >= 2100) return 255;
    return (uint8_t)(((uint32_t)(us - 900) * 255UL + 600UL) / 1200UL);
}


uint8_t RcSpcmGenClass::makeFailsafeAux(uint8_t serviceBase, uint16_t fs)
{
    uint8_t index = (serviceBase >> 2) & 0x03;
    uint8_t part = (uint8_t)((fs >> (2 + 2 * index)) & 0x03);
    return (uint8_t)((serviceBase & 0x1C) | part);
}

void RcSpcmGenClass::applyFailsafeToAux(uint8_t &aux, uint8_t channelIndex) const
{
    if(aux >= 16 && channelIndex < RC_SPCM_FAILSAFE_CH_NB)
        aux = makeFailsafeAux(aux, _FailsafeSpcm[channelIndex]);
}

void RcSpcmGenClass::setSpcmChannel(uint8_t q[32], uint8_t Position, uint16_t Value)
{
    Value &= 0x03FF;
    q[Position]   = (Value >> 5) & 0x1F;
    q[Position+1] = Value & 0x1F;
}

uint8_t RcSpcmGenClass::crc8(const uint8_t data[4], uint8_t poly)
{
    uint8_t crc = 0;
    for(uint8_t n=0; n<4; ++n)
    {
        crc ^= data[n];
        for(uint8_t b=0; b<8; ++b)
            crc = (crc & 0x80) ? (uint8_t)((crc << 1) ^ poly) : (uint8_t)(crc << 1);
    }
    return crc;
}

void RcSpcmGenClass::makeProtectedData(const uint8_t q[32], uint8_t Start,
                                       uint8_t CtrlHigh, uint8_t data[4])
{
    uint8_t bits[32];
    uint8_t p = 0;
    for(uint8_t n=0; n<6; ++n)
    {
        uint8_t v = q[Start+n] & 0x1F;
        for(int8_t b=4; b>=0; --b) bits[p++] = (v >> b) & 1;
    }
    bits[p++] = (CtrlHigh >> 1) & 1;
    bits[p++] = CtrlHigh & 1;

    for(uint8_t n=0; n<4; ++n)
    {
        uint8_t v=0;
        for(uint8_t b=0; b<8; ++b) v = (uint8_t)((v << 1) | bits[n*8+b]);
        data[n]=v;
    }
}

void RcSpcmGenClass::makeCtrl(uint8_t q[32], uint8_t Start, uint8_t CtrlPosition,
                              uint8_t CtrlHigh, uint8_t Polynomial)
{
    uint8_t data[4];
    makeProtectedData(q, Start, CtrlHigh, data);
    uint16_t ctrl = ((uint16_t)(CtrlHigh & 3) << 8) | crc8(data, Polynomial);
    q[CtrlPosition]   = (ctrl >> 5) & 0x1F;
    q[CtrlPosition+1] = ctrl & 0x1F;
}

void RcSpcmGenClass::buildLogicalFrame(uint8_t q[32], uint32_t FrameNumber)
{
    memset(q, 0, 32);
    uint8_t s = FrameNumber & 7;

    q[0]=Service[s][0]; q[3]=Service[s][1];
    q[8]=Service[s][2]; q[11]=Service[s][3];
    q[18]=Service[s][4]; q[21]=Service[s][5];
    q[26]=Service[s][6]; q[29]=Service[s][7];

    // Fail-Safe CH1..CH8 in AUX1..AUX8.
    applyFailsafeToAux(q[0],  0);
    applyFailsafeToAux(q[18], 1);
    applyFailsafeToAux(q[3],  2);
    applyFailsafeToAux(q[21], 3);
    applyFailsafeToAux(q[8],  4);
    applyFailsafeToAux(q[26], 5);
    applyFailsafeToAux(q[11], 6);
    applyFailsafeToAux(q[29], 7);

    uint16_t ch[RC_SPCM_CH_NB];
    for(uint8_t i=0; i<RC_SPCM_CH_NB; ++i) ch[i]=width_us(i+1);

    // CH9 / CH10 Extra Channels (8-bit), in their scheduled primary slots.
    uint8_t ch9 = usToSpcmHighChannel(ch[8]);
    if(q[0] < 16 && q[3] < 16)
    {
        q[0] = (ch9 >> 4) & 0x0F;
        q[3] = ch9 & 0x0F;
    }

    uint8_t ch10 = usToSpcmHighChannel(ch[9]);
    if(q[18] < 16 && q[21] < 16)
    {
        q[18] = (ch10 >> 4) & 0x0F;
        q[21] = ch10 & 0x0F;
    }

    setSpcmChannel(q,16,usToSpcm(ch[0]));
    setSpcmChannel(q, 1,usToSpcm(ch[1]));
    setSpcmChannel(q,19,usToSpcm(ch[2]));
    setSpcmChannel(q, 4,usToSpcm(ch[3]));
    setSpcmChannel(q,24,usToSpcm(ch[4]));
    setSpcmChannel(q, 9,usToSpcm(ch[5]));
    setSpcmChannel(q,27,usToSpcm(ch[6]));
    setSpcmChannel(q,12,usToSpcm(ch[7]));

    // Both AUX control bits remain in Fail-Safe/Extra mode.
    // Relative-channel generation is intentionally not implemented.
    makeCtrl(q, 0, 6,3,0x31);
    makeCtrl(q, 8,14,3,0x13);
    makeCtrl(q,16,22,3,0x91);
    makeCtrl(q,24,30,3,0x19);
}

void RcSpcmGenClass::makePhysicalBits(const uint8_t q[32], uint8_t bits[256])
{
    uint16_t p=0;
    for(uint8_t n=0; n<32; ++n)
    {
        uint8_t physical=QuintetToPhysical[q[n]&0x1F];
        for(int8_t b=7; b>=0; --b) bits[p++]=(physical>>b)&1;
    }
}

uint32_t RcSpcmGenClass::ticksToUs(uint16_t ticks)
{
    return ((uint32_t)ticks * 1664UL + 5UL) / 10UL;
}

void RcSpcmGenClass::waitUntilUs(uint32_t target)
{
    while((int32_t)(micros() - target) < 0) {}
}

void RcSpcmGenClass::sendPhysicalFrame(const uint8_t bits[256])
{
    uint32_t frameStart = micros();

    writePhysical(1);
    uint32_t syncEnd = frameStart + RC_SPCM_DEFAULT_SYNC_US;
    waitUntilUs(syncEnd);
    writePhysical(0);

    int16_t firstOne=-1;
    uint16_t ones=0;
    for(uint16_t i=0; i<256; ++i)
    {
        if(bits[i])
        {
            ++ones;
            if(firstOne < 0) firstOne=(int16_t)i;
        }
    }
    if(firstOne < 0) return;

    waitUntilUs(syncEnd + ticksToUs((uint16_t)firstOne + 1));
    uint8_t level=1;
    writePhysical(1);

    for(uint16_t i=(uint16_t)firstOne+1; i<256; ++i)
    {
        if(!bits[i]) continue;
        waitUntilUs(syncEnd + ticksToUs(i+1));
        level=!level;
        writePhysical(level);
    }

    if((ones & 1)==0)
    {
        waitUntilUs(syncEnd + ticksToUs(258));
        writePhysical(1);
        waitUntilUs(syncEnd + ticksToUs(260));
        writePhysical(0);
    }
    else
    {
        waitUntilUs(syncEnd + ticksToUs(260));
        writePhysical(0);
    }
}

#if defined(ARDUINO_ARCH_AVR)

static inline uint32_t rcSpcmAvrUsToCounts(uint32_t us)
{
    // Timer1 prescaler /8. Rounded conversion, performed outside the ISR.
    const uint64_t n=(uint64_t)us*(uint64_t)(F_CPU/8UL);
    return (uint32_t)((n+500000ULL)/1000000ULL);
}

uint32_t RcSpcmGenClass::avrTicksToCounts(uint16_t ticks) const
{
    // One SPCM tick = 166.4 us. Absolute conversion prevents cumulative drift.
    const uint64_t n=(uint64_t)ticks*1664ULL*(uint64_t)(F_CPU/8UL);
    return (uint32_t)((n+5000000ULL)/10000000ULL);
}

void RcSpcmGenClass::avrMakePhysicalBytes(const uint8_t q[32], uint8_t physical[32]) const
{
    for(uint8_t i=0;i<32;++i) physical[i]=QuintetToPhysical[q[i]&0x1F];
}

uint16_t RcSpcmGenClass::avrBuildDurations(const uint8_t physical[32], uint16_t *dst) const
{
    uint16_t out=0;
    uint16_t ones=0;
    uint32_t previous=0;

    // End of SYNC.
    dst[out++]=_AvrSyncCounts;
    previous=_AvrSyncCounts;

    // Physical transitions at SYNC + (bit+1)*166.4 us.
    for(uint16_t i=0;i<256;++i) {
        if(!(physical[i>>3] & (0x80U>>(i&7)))) continue;
        ++ones;
        uint32_t transition=(uint32_t)_AvrSyncCounts+avrTicksToCounts((uint16_t)(i+1U));
        uint32_t d=transition-previous;
        if(!d || d>65535UL || out>=(RC_SPCM_AVR_MAX_DURATIONS-3)) return 0;
        dst[out++]=(uint16_t)d;
        previous=transition;
    }

    // Validated ESP32/V11 EOF parity rule.
    if((ones&1U)==0) {
        uint32_t transition=(uint32_t)_AvrSyncCounts+avrTicksToCounts(258);
        uint32_t d=transition-previous;
        if(!d || d>65535UL || out>=RC_SPCM_AVR_MAX_DURATIONS) return 0;
        dst[out++]=(uint16_t)d;
        previous=transition;
    }

    {
        uint32_t transition=(uint32_t)_AvrSyncCounts+avrTicksToCounts(260);
        uint32_t d=transition-previous;
        if(!d || d>65535UL || out>=RC_SPCM_AVR_MAX_DURATIONS) return 0;
        dst[out++]=(uint16_t)d;
        previous=transition;
    }

    if(_AvrFrameCounts<=previous) return 0;
    uint32_t pad=_AvrFrameCounts-previous;
    if(!pad || pad>65535UL || out>=RC_SPCM_AVR_MAX_DURATIONS) return 0;
    dst[out++]=(uint16_t)pad;
    return out;
}

void RcSpcmGenClass::avrStartTimer(void)
{
    _AvrSyncCounts=(uint16_t)rcSpcmAvrUsToCounts(RC_SPCM_DEFAULT_SYNC_US);
    _AvrFrameCounts=rcSpcmAvrUsToCounts(_FramePeriodUs);

    // begin() built buffer 0 before these values were initialized, so rebuild
    // it now using the final timer-count constants.
    uint8_t q[32], physical[32];
    buildLogicalFrame(q,0);
    avrMakePhysicalBytes(q,physical);
    _AvrDurationCount[0]=avrBuildDurations(physical,_AvrDurationBuf[0]);
    if(!_AvrDurationCount[0]) { _Running=0; return; }

    uint8_t sreg=SREG; cli();
    TCCR1A=0;
    TCCR1B=0;
    TCCR1C=0;
    TCNT1=0;

    // Force the OC1B pin to the idle GPIO state, then switch OC1B to TOGGLE.
    // Validated BC547 interface (INVERTED): GPIO HIGH = transistor ON = SPCM LOW.
    if(_Inverted) TCCR1A=_BV(COM1B1)|_BV(COM1B0); // SET OC1B on forced compare
    else          TCCR1A=_BV(COM1B1);             // CLEAR OC1B on forced compare
    TCCR1C=_BV(FOC1B);
    TCCR1A=_BV(COM1B0);                            // TOGGLE OC1B on compare

    // As in the validated V11/OpenAVRc-style engine, the first compare occurs
    // 300 us later and marks the exact start of frame 0 / SYNC.
    OCR1B=TCNT1+(uint16_t)rcSpcmAvrUsToCounts(300UL);
    TIFR1=_BV(OCF1B);
    TIMSK1|=_BV(OCIE1B);
    TCCR1B=_BV(CS11);                              // Timer1 /8
    SREG=sreg;
}

void RcSpcmGenClass::avrTimerIsr(void)
{
    if(!_Running) return;

    uint8_t a=_AvrActiveBuf;
    uint16_t idx=_AvrTxDurationIdx;

    // OC1B has already toggled in hardware when the ISR starts.
    if(idx>=_AvrDurationCount[a]) {
        if(_AvrPendingReady) {
            _AvrActiveBuf=_AvrPendingBuf;
            _AvrPendingReady=0;
        }
        ++_AvrTxFrameNumber;
        a=_AvrActiveBuf;
        idx=0;
    }

    OCR1B+=_AvrDurationBuf[a][idx];
    _AvrTxDurationIdx=(uint16_t)(idx+1U);
}

char RcSpcmGenClass::avrBuildFramePt(struct pt *pt)
{
    PT_BEGIN(pt);

    while(1) {
        PT_WAIT_UNTIL(pt,!_AvrPendingReady);

        // With no pending buffer, ActiveBuf cannot change until this PT publishes.
        _AvrPtCtx.target=(uint8_t)(_AvrActiveBuf^1U);
        {
            uint8_t sreg=SREG; cli();
            _AvrPtCtx.frameNumber=_AvrTxFrameNumber+1UL;
            SREG=sreg;
        }

        buildLogicalFrame(_AvrPtCtx.q,_AvrPtCtx.frameNumber);
        PT_YIELD(pt);

        avrMakePhysicalBytes(_AvrPtCtx.q,_AvrPtCtx.physical);
        PT_YIELD(pt);

        // FULL-PT duration builder: one physical transition per cooperative slice.
        _AvrPtCtx.out=0;
        _AvrPtCtx.ones=0;
        _AvrPtCtx.bitIndex=0;
        _AvrPtCtx.previous=_AvrSyncCounts;
        _AvrDurationBuf[_AvrPtCtx.target][_AvrPtCtx.out++]=_AvrSyncCounts;

        while(_AvrPtCtx.bitIndex<256) {
            while(_AvrPtCtx.bitIndex<256 &&
                  !(_AvrPtCtx.physical[_AvrPtCtx.bitIndex>>3] &
                    (0x80U>>(_AvrPtCtx.bitIndex&7)))) {
                ++_AvrPtCtx.bitIndex;
            }

            if(_AvrPtCtx.bitIndex<256) {
                ++_AvrPtCtx.ones;
                _AvrPtCtx.transition=(uint32_t)_AvrSyncCounts+
                    avrTicksToCounts((uint16_t)(_AvrPtCtx.bitIndex+1U));
                _AvrPtCtx.delta=_AvrPtCtx.transition-_AvrPtCtx.previous;

                if(!_AvrPtCtx.delta || _AvrPtCtx.delta>65535UL ||
                   _AvrPtCtx.out>=(RC_SPCM_AVR_MAX_DURATIONS-3)) {
                    _AvrPtCtx.out=0;
                    break;
                }

                _AvrDurationBuf[_AvrPtCtx.target][_AvrPtCtx.out++]=(uint16_t)_AvrPtCtx.delta;
                _AvrPtCtx.previous=_AvrPtCtx.transition;
                ++_AvrPtCtx.bitIndex;
                PT_YIELD(pt);
            }
        }

        if(_AvrPtCtx.out && ((_AvrPtCtx.ones&1U)==0)) {
            _AvrPtCtx.transition=(uint32_t)_AvrSyncCounts+avrTicksToCounts(258);
            _AvrPtCtx.delta=_AvrPtCtx.transition-_AvrPtCtx.previous;
            if(_AvrPtCtx.delta && _AvrPtCtx.delta<=65535UL &&
               _AvrPtCtx.out<RC_SPCM_AVR_MAX_DURATIONS) {
                _AvrDurationBuf[_AvrPtCtx.target][_AvrPtCtx.out++]=(uint16_t)_AvrPtCtx.delta;
                _AvrPtCtx.previous=_AvrPtCtx.transition;
            } else _AvrPtCtx.out=0;
        }

        if(_AvrPtCtx.out) {
            _AvrPtCtx.transition=(uint32_t)_AvrSyncCounts+avrTicksToCounts(260);
            _AvrPtCtx.delta=_AvrPtCtx.transition-_AvrPtCtx.previous;
            if(_AvrPtCtx.delta && _AvrPtCtx.delta<=65535UL &&
               _AvrPtCtx.out<RC_SPCM_AVR_MAX_DURATIONS) {
                _AvrDurationBuf[_AvrPtCtx.target][_AvrPtCtx.out++]=(uint16_t)_AvrPtCtx.delta;
                _AvrPtCtx.previous=_AvrPtCtx.transition;
            } else _AvrPtCtx.out=0;
        }

        if(_AvrPtCtx.out) {
            _AvrPtCtx.delta=_AvrFrameCounts-_AvrPtCtx.previous;
            if(_AvrPtCtx.delta && _AvrPtCtx.delta<=65535UL &&
               _AvrPtCtx.out<RC_SPCM_AVR_MAX_DURATIONS) {
                _AvrDurationBuf[_AvrPtCtx.target][_AvrPtCtx.out++]=(uint16_t)_AvrPtCtx.delta;
            } else _AvrPtCtx.out=0;
        }

        if(_AvrPtCtx.out) {
            uint8_t sreg=SREG; cli();
            _AvrDurationCount[_AvrPtCtx.target]=_AvrPtCtx.out;
            _AvrPendingBuf=_AvrPtCtx.target;
            _AvrPendingReady=1;
            SREG=sreg;
            ++_AvrPublishCount;
        }

        PT_WAIT_UNTIL(pt,!_AvrPendingReady);
    }

    PT_END(pt);
}

uint8_t RcSpcmGenClass::refresh(uint8_t force)
{
    if(!_Running) return 0;
    uint32_t before=_AvrPublishCount;

    // Normal operation mirrors the hardware-validated PT5 sketch: one
    // cooperative slice each time process()/refresh() is serviced.
    uint8_t slices=force ? 104U : 1U;
    while(slices--) {
        PT_SCHEDULE(avrBuildFramePt(&_AvrPt));
        if(_AvrPublishCount!=before)
        {
            _RculSynchro = 0xFFU;
            return 1;
        }
        if(_AvrPendingReady) break;
    }
    return 0;
}
#else

uint8_t RcSpcmGenClass::refresh(uint8_t force)
{
    if(!_Running) return 0;
    uint32_t now = micros();
    if(!force && (int32_t)(now - _NextFrameUs) < 0) return 0;
    if(force) _NextFrameUs = now + _FramePeriodUs;
    else { do { _NextFrameUs += _FramePeriodUs; } while((int32_t)(now - _NextFrameUs) >= 0); }
    uint8_t q[32]; uint8_t bits[256];
    buildLogicalFrame(q, _FrameNumber++);
    makePhysicalBits(q, bits);
    sendPhysicalFrame(bits);

    _RculSynchro = 0xFFU;
    return 1;
}

#endif
