/*
  RcSpcmGen - Graupner/JR SPCM 1024 generator
  RCUL compatible
  AVR + ESP32
  Version 0.5.2 - 2026-10-06
*/
#ifndef RCSPCMGEN_H
#define RCSPCMGEN_H

#include <Arduino.h>
#include <Rcul.h>
#if defined(ARDUINO_ARCH_AVR)
#include "pt/pt.h"
#endif

#define RC_SPCM_GEN_VERSION        "0.5.2"
#define RC_SPCM_CH_NB              10
#define RC_SPCM_FAILSAFE_CH_NB     8
#define RC_SPCM_NORMAL             0
#define RC_SPCM_INVERTED           1
#define RC_SPCM_DEFAULT_FRAME_US   44025UL
#define RC_SPCM_DEFAULT_SYNC_US    415UL
#define RC_SPCM_AVR_MAX_DURATIONS  104

class RcSpcmGenClass : public Rcul
{
public:
    RcSpcmGenClass();

    // Inverted=true is the validated BC547 open-collector interface.
    bool begin(uint8_t Pin, uint8_t Inverted = RC_SPCM_INVERTED);
    void end(void);
    // Diagnostic transport control: preserve channels/Fail-Safe while stopping/starting SPCM.
    void stop(void) { end(); }
    bool start(void);

    /*
      Native generator service.
      Returns 1 when a new SPCM frame/buffer has been produced.
      Each successful refresh also latches one RCUL synchronization event
      for every RCUL client. force=1 forces a refresh immediately.
    */
    uint8_t refresh(uint8_t force = 0);

    // Service the generator regularly. RCUL users must call this too;
    // RculIsSynchro() only consumes a latched synchronization event.
    void process(void) { (void)refresh(); }

    void width_us(uint8_t Ch, uint16_t Width_us);
    uint16_t width_us(uint8_t Ch) const;
    void setChannelUs(uint8_t Ch, uint16_t Width_us) { width_us(Ch, Width_us); }
    uint16_t channelUs(uint8_t Ch) const { return width_us(Ch); }
    void setNeutral(void);

    // SPCM Fail-Safe, channels 1..8 only. FS=0 means HOLD/OFF.
    void setFailsafeUs(uint8_t Ch, uint16_t Width_us);
    void setFailsafeHold(uint8_t Ch);
    uint16_t getFailsafeUs(uint8_t Ch) const; // 0 = HOLD/OFF
    void setFailsafeOff(uint8_t Ch) { setFailsafeHold(Ch); }
    void setAllFailsafeHold(void);

    uint8_t isRunning(void) const { return _Running; }

    void setFramePeriodUs(uint32_t PeriodUs) { _FramePeriodUs = PeriodUs; }
    uint32_t framePeriodUs(void) const { return _FramePeriodUs; }

    static const char *version(void) { return RC_SPCM_GEN_VERSION; }

    // RCUL interface
    virtual uint8_t  RculIsSynchro(uint8_t ClientIdx = RCUL_DEFAULT_CLIENT_IDX);
    virtual uint16_t RculGetWidth_us(uint8_t Ch);
    virtual void     RculSetWidth_us(uint16_t Width_us, uint8_t Ch = RCUL_NO_CH);

#if defined(ARDUINO_ARCH_AVR)
    // Internal Timer1 ISR entry point (AVR backend).
    void avrTimerIsr(void);
#endif

private:
    uint8_t  _Pin;
    uint8_t  _Inverted;
    uint8_t  _Running;
    uint16_t _ChannelUs[RC_SPCM_CH_NB];
    uint16_t _FailsafeSpcm[RC_SPCM_FAILSAFE_CH_NB];
    uint16_t _FailsafeUs[RC_SPCM_FAILSAFE_CH_NB];
    uint32_t _FrameNumber;
    uint32_t _NextFrameUs;
    uint32_t _FramePeriodUs;

    // One latched synchronization bit per RcTxSerial/RCUL client.
    // Bit N is cleared only when client N consumes it via RculIsSynchro().
    uint8_t  _RculSynchro;

#if defined(ARDUINO_ARCH_AVR)
    volatile uint8_t *_AvrPort;
    uint8_t _AvrMask;

    // Validated AVR backend derived from the ATmega2560 V11/PT5 FULL-PT
    // reference. Timer1 /8 drives OC1B in hardware toggle mode; the ISR only
    // schedules the next already-built duration.
    uint16_t _AvrDurationBuf[2][RC_SPCM_AVR_MAX_DURATIONS];
    volatile uint16_t _AvrDurationCount[2];
    volatile uint8_t  _AvrActiveBuf;
    volatile uint8_t  _AvrPendingBuf;
    volatile uint8_t  _AvrPendingReady;
    volatile uint16_t _AvrTxDurationIdx;
    volatile uint32_t _AvrTxFrameNumber;

    uint16_t _AvrSyncCounts;
    uint32_t _AvrFrameCounts;

    struct AvrPtContext {
        uint8_t target;
        uint32_t frameNumber;
        uint8_t q[32];
        uint8_t physical[32];
        uint16_t bitIndex;
        uint16_t ones;
        uint32_t previous;
        uint32_t transition;
        uint32_t delta;
        uint16_t out;
    };

    struct pt _AvrPt;
    AvrPtContext _AvrPtCtx;
    uint32_t _AvrPublishCount;

    void avrStartTimer(void);
    uint32_t avrTicksToCounts(uint16_t ticks) const;
    uint16_t avrBuildDurations(const uint8_t physical[32], uint16_t *dst) const;
    void avrMakePhysicalBytes(const uint8_t q[32], uint8_t physical[32]) const;
    char avrBuildFramePt(struct pt *pt);
#endif

    void writePhysical(uint8_t Level);
    void buildLogicalFrame(uint8_t q[32], uint32_t FrameNumber);
    void makePhysicalBits(const uint8_t q[32], uint8_t bits[256]);
    void sendPhysicalFrame(const uint8_t bits[256]);

    static uint16_t usToSpcm(uint16_t us);
    static uint8_t usToSpcmHighChannel(uint16_t us);
    static uint8_t makeFailsafeAux(uint8_t serviceBase, uint16_t fs);
    void applyFailsafeToAux(uint8_t &aux, uint8_t channelIndex) const;
    static uint8_t crc8(const uint8_t data[4], uint8_t poly);
    static void setSpcmChannel(uint8_t q[32], uint8_t Position, uint16_t Value);
    static void makeProtectedData(const uint8_t q[32], uint8_t Start,
                                  uint8_t CtrlHigh, uint8_t data[4]);
    static void makeCtrl(uint8_t q[32], uint8_t Start, uint8_t CtrlPosition,
                         uint8_t CtrlHigh, uint8_t Polynomial);
    static uint32_t ticksToUs(uint16_t ticks);
    static void waitUntilUs(uint32_t target);
};

extern RcSpcmGenClass RcSpcmGen;

#endif
